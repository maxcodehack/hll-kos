#include <menuet.h>
#include <me_heap.h>
#include <me_file.h>

using namespace Menuet;

const char header[] = "HelloWorld test";
const char string[] = "Hello, World!";

bool MenuetOnStart(TStartData &me_start, TThreadData /*th*/)
{
	me_start.Left = 10;
	me_start.Top = 40;
	me_start.Width = 150;
	me_start.Height = 30;
	me_start.WinData.Title = header;
	return true;
}

void MenuetOnDraw(void)
{
	DrawString(30,10,0,string);
}

bool MenuetOnClose(TThreadData /*th*/)
{return true;}
int MenuetOnIdle(TThreadData /*th*/)
{return -1;}
void MenuetOnSize(int /*window_rect*/[], TThreadData /*th*/)
{}
void MenuetOnKeyPress(TThreadData /*th*/)
{GetKey();}
void MenuetOnMouse(TThreadData /*th*/)
{}
