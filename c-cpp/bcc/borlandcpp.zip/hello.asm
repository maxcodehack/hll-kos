	.686p
	ifdef ??version
	if    ??version GT 500H
	.mmx
	endif
	endif
	model flat
	ifndef	??version
	?debug	macro
	endm
	endif
	?debug	S "hello.cpp"
	?debug	T "hello.cpp"
_TEXT	segment dword public use32 'CODE'
_TEXT	ends
_DATA	segment dword public use32 'DATA'
_DATA	ends
_BSS	segment dword public use32 'BSS'
_BSS	ends
DGROUP	group	_BSS,_DATA
_DATA	segment dword public use32 'DATA'
	align	4
@Menuet@DebugPrefix	label	dword
	dd	s@
_DATA	ends
_BSS	segment dword public use32 'BSS'
	align	4
@Menuet@_ThreadTable	label	dword
	db	1024	dup(?)
_BSS	ends
_DATA	segment dword public use32 'DATA'
	align	4
@Menuet@_ThreadScanCount	label	dword
	dd	0
	dd	0
	align	4
@Menuet@_ThreadNumber	label	dword
	dd	1
	align	4
@Menuet@_ExitProcessNow	label	dword
	dd	0
	align	4
@Menuet@_ThreadMutex	label	byte
	dd	64
_DATA	ends
_BSS	segment dword public use32 'BSS'
	align	4
@Menuet@_ThreadSavedBegProc	label	dword
	db	16	dup(?)
_BSS	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@_GetStartData$qr17Menuet@TStartDatappv	segment virtual
	align	2
@@Menuet@_GetStartData$qr17Menuet@TStartDatappv	proc	near
?live16385@0:
   ;	
   ;		void _GetStartData(TStartData &start_data, TThreadData thread_data)
   ;	
@1:
	push      ebp
	mov       ebp,esp
	mov       edx,dword ptr [ebp+12]
	mov       eax,dword ptr [ebp+8]
   ;	
   ;		{
   ;			start_data.Left = (unsigned short)((unsigned long)thread_data[MENUET_THREAD_DATA_X] >> 16);
   ;	
?live16385@16: ; EAX = start_data, EDX = thread_data
	mov       ecx,dword ptr [edx+20]
	shr       ecx,16
	mov       word ptr [eax],cx
   ;	
   ;			start_data.Width = (unsigned short)((unsigned long)thread_data[MENUET_THREAD_DATA_X]);
   ;	
	mov       cx,word ptr [edx+20]
	mov       word ptr [eax+2],cx
   ;	
   ;			start_data.Top = (unsigned short)((unsigned long)thread_data[MENUET_THREAD_DATA_Y] >> 16);
   ;	
	mov       ecx,dword ptr [edx+24]
	shr       ecx,16
	mov       word ptr [eax+4],cx
   ;	
   ;			start_data.Height = (unsigned short)((unsigned long)thread_data[MENUET_THREAD_DATA_Y]);
   ;	
	mov       cx,word ptr [edx+24]
	mov       word ptr [eax+6],cx
   ;	
   ;			GetWindowData(start_data.WinData, thread_data);
   ;	
	push      edx
	add       eax,8
	push      eax
	call      @@Menuet@GetWindowData$qr18Menuet@TWindowDatappv
	add       esp,8
   ;	
   ;		}
   ;	
?live16385@96: ; 
@2:
	pop       ebp
	ret 
@@Menuet@_GetStartData$qr17Menuet@TStartDatappv	endp
@Menuet@_GetStartData$qr17Menuet@TStartDatappv	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@_SetStartData$qrx17Menuet@TStartDatappv	segment virtual
	align	2
@@Menuet@_SetStartData$qrx17Menuet@TStartDatappv	proc	near
?live16386@0:
   ;	
   ;		void _SetStartData(const TStartData &start_data, TThreadData thread_data)
   ;	
@3:
	push      ebp
	mov       ebp,esp
	push      ebx
	mov       eax,dword ptr [ebp+8]
	mov       edx,dword ptr [ebp+12]
   ;	
   ;		{
   ;			(unsigned long&)thread_data[MENUET_THREAD_DATA_X] =
   ;	
?live16386@16: ; EAX = start_data, EDX = thread_data
	movzx     ecx,word ptr [eax]
	movzx     ebx,word ptr [eax+2]
	shl       ecx,16
	or        ecx,ebx
	mov       dword ptr [edx+20],ecx
   ;	
   ;						((unsigned int)start_data.Left << 16) | start_data.Width;
   ;			(unsigned long&)thread_data[MENUET_THREAD_DATA_Y] =
   ;	
	movzx     ecx,word ptr [eax+4]
	movzx     ebx,word ptr [eax+6]
	shl       ecx,16
	or        ecx,ebx
   ;	
   ;						((unsigned int)start_data.Top << 16) | start_data.Height;
   ;			SetWindowData(start_data.WinData, thread_data);
   ;	
	add       eax,8
	mov       dword ptr [edx+24],ecx
	push      edx
	push      eax
	call      @@Menuet@SetWindowData$qrx18Menuet@TWindowDatappv
	add       esp,8
   ;	
   ;		}
   ;	
?live16386@96: ; 
@4:
	pop       ebx
	pop       ebp
	ret 
@@Menuet@_SetStartData$qrx17Menuet@TStartDatappv	endp
@Menuet@_SetStartData$qrx17Menuet@TStartDatappv	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@_ApplyCommonColors$qr18Menuet@TWindowData	segment virtual
	align	2
@@Menuet@_ApplyCommonColors$qr18Menuet@TWindowData	proc	near
?live16387@0:
   ;	
   ;		void _ApplyCommonColors(TWindowData &win_data)
   ;	
@5:
	push      ebp
	mov       ebp,esp
	add       esp,-40
	push      ebx
	mov       ebx,dword ptr [ebp+8]
   ;	
   ;		{
   ;			unsigned int colors[10];
   ;			ReadCommonColors(colors);
   ;	
?live16387@16: ; EBX = win_data
	lea       eax,dword ptr [ebp-40]
	push      eax
	call      @@Menuet@ReadCommonColors$qpui
	pop       ecx
   ;	
   ;			win_data.WindowColor = colors[5];
   ;	
	mov       edx,dword ptr [ebp-20]
	mov       dword ptr [ebx+4],edx
   ;	
   ;			win_data.HeaderColor = colors[1];
   ;	
	mov       ecx,dword ptr [ebp-36]
	mov       dword ptr [ebx+8],ecx
   ;	
   ;			win_data.BorderColor = colors[0];
   ;	
	mov       eax,dword ptr [ebp-40]
	mov       dword ptr [ebx+12],eax
   ;	
   ;			win_data.TitleColor = colors[4];
   ;	
	mov       edx,dword ptr [ebp-24]
	mov       dword ptr [ebx+16],edx
   ;	
   ;		}
   ;	
?live16387@96: ; 
@6:
	pop       ebx
	mov       esp,ebp
	pop       ebp
	ret 
@@Menuet@_ApplyCommonColors$qr18Menuet@TWindowData	endp
@Menuet@_ApplyCommonColors$qr18Menuet@TWindowData	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@_SetValueFunctionPriority$qpvi	segment virtual
	align	2
@@Menuet@_SetValueFunctionPriority$qpvi	proc	near
?live16388@0:
   ;	
   ;		void _SetValueFunctionPriority(void *beg, int n)
   ;	
@7:
	push      ebp
	mov       ebp,esp
	add       esp,-256
	push      ebx
	push      esi
	mov       esi,dword ptr [ebp+12]
   ;	
   ;		{
   ;			int k, i;
   ;			unsigned char num[256];
   ;			for (i = 0; i < 256; i++) num[i] = 0;
   ;	
?live16388@16: ; ESI = n
	xor       eax,eax
	lea       edx,dword ptr [ebp-256]
@8:
	mov       byte ptr [edx],0
	inc       eax
	inc       edx
	cmp       eax,256
	jl        short @8
   ;	
   ;			for (k = 0; k < n; k++)
   ;	
	xor       ecx,ecx
	mov       eax,dword ptr [ebp+8]
	lea       edx,dword ptr [eax+1]
	cmp       esi,ecx
	jle       short @12
   ;	
   ;			{
   ;				i = ((unsigned char*)beg + 6*k)[1];
   ;	
?live16388@48: ; EDX = @temp1, ECX = k, ESI = n
@11:
	xor       eax,eax
	mov       al,byte ptr [edx]
   ;	
   ;				((unsigned char*)beg + 6*k)[0] = num[i];
   ;	
?live16388@64: ; EAX = i, EDX = @temp1, ECX = k, ESI = n
	mov       bl,byte ptr [ebp+eax-256]
	mov       byte ptr [edx-1],bl
   ;	
   ;				if (num[i] != 255) num[i]++;
   ;	
	cmp       byte ptr [ebp+eax-256],-1
	je        short @13
	inc       byte ptr [ebp+eax-256]
@13:
	inc       ecx
	add       edx,6
	cmp       esi,ecx
	jg        short @11
   ;	
   ;			}
   ;		}
   ;	
?live16388@96: ; 
@12:
@15:
	pop       esi
	pop       ebx
	mov       esp,ebp
	pop       ebp
	ret 
@@Menuet@_SetValueFunctionPriority$qpvi	endp
@Menuet@_SetValueFunctionPriority$qpvi	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@_CallFunctionPriority$qpvt1o	segment virtual
	align	2
@@Menuet@_CallFunctionPriority$qpvt1o	proc	near
?live16389@0:
   ;	
   ;		void _CallFunctionPriority(void *beg, void *end, bool reverse = false)
   ;	
@16:
	push      ebp
	mov       ebp,esp
	add       esp,-76
	push      ebx
	push      esi
	mov       esi,dword ptr [ebp+8]
   ;	
   ;		{
   ;			struct _Local
   ;			{
   ;				static int cmp(void *beg, int i, int j)
   ;				{
   ;					unsigned char *x = (unsigned char*)beg + 6*i;
   ;					unsigned char *y = (unsigned char*)beg + 6*j;
   ;					if (*(unsigned short*)x < *(unsigned short*)y) return -1;
   ;					if (*(unsigned short*)x > *(unsigned short*)y) return 1;
   ;					return 0;
   ;				}
   ;	
   ;				static void swap(void *beg, int i, int j)
   ;				{
   ;					unsigned char *x = (unsigned char*)beg + 6*i;
   ;					unsigned char *y = (unsigned char*)beg + 6*j;
   ;					short s;
   ;					int t;
   ;					s = *(short*)x; *(short*)x = *(short*)y; *(short*)y = s;
   ;					x += 2; y += 2;
   ;					t = *(int*)x; *(int*)x = *(int*)y; *(int*)y = t;
   ;				}
   ;	
   ;				static void call(void *beg, int i)
   ;				{
   ;					unsigned char *x = (unsigned char*)beg + 6*i;
   ;					(*(void(**)())(x+2))();
   ;				}
   ;			};
   ;	
   ;			if (!beg || !end || end <= beg) return;
   ;	
?live16389@16: ; ESI = beg
	test      esi,esi
	je        @19
	cmp       dword ptr [ebp+12],0
	je        @19
	cmp       esi,dword ptr [ebp+12]
	jae       @19
   ;	
   ;			int i, j, k, m, n;
   ;			n = ((unsigned char*)end - (unsigned char*)beg) / 6;
   ;	
	mov       eax,dword ptr [ebp+12]
	sub       eax,esi
	mov       ecx,6
	cdq
	idiv      ecx
	mov       dword ptr [ebp-12],eax
   ;	
   ;			if (n <= 0) return;
   ;	
	cmp       dword ptr [ebp-12],0
	jle       @19
   ;	
   ;			_SetValueFunctionPriority(beg, n);
   ;	
	mov       eax,dword ptr [ebp-12]
	push      eax
	push      esi
	call      @@Menuet@_SetValueFunctionPriority$qpvi
	add       esp,8
   ;	
   ;			m = n; k = n;
   ;	
	mov       edx,dword ptr [ebp-12]
	mov       dword ptr [ebp-8],edx
	mov       ecx,dword ptr [ebp-12]
	mov       dword ptr [ebp-4],ecx
   ;	
   ;			while (m > 1)
   ;	
	cmp       dword ptr [ebp-8],1
	jle       @22
   ;	
   ;			{
   ;				if (k > 0) k--;
   ;	
@21:
	cmp       dword ptr [ebp-4],0
	jle       short @23
	dec       dword ptr [ebp-4]
	jmp       short @24
   ;	
   ;				else _Local::swap(beg, 0, --m);
   ;	
@23:
	dec       dword ptr [ebp-8]
	mov       edx,esi
	mov       ecx,dword ptr [ebp-8]
	mov       eax,edx
	add       ecx,ecx
	lea       ecx,dword ptr [ecx+2*ecx]
	add       edx,ecx
	mov       cx,word ptr [eax]
	mov       bx,word ptr [edx]
	mov       word ptr [eax],bx
	add       eax,2
	mov       word ptr [edx],cx
	add       edx,2
	mov       ecx,dword ptr [eax]
	mov       ebx,dword ptr [edx]
	mov       dword ptr [eax],ebx
	mov       dword ptr [edx],ecx
   ;	
   ;				j = k;
   ;	
@24:
	mov       edx,dword ptr [ebp-4]
   ;	
   ;				for (;;)
   ;				{
   ;					 i = j;
   ;	
?live16389@160: ; EDX = j, ESI = beg
@25:
	mov       eax,edx
   ;	
   ;					 if (2*i + 1 >= m) break;
   ;	
?live16389@176: ; EAX = i, EDX = j, ESI = beg
	mov       ecx,eax
	add       ecx,ecx
	inc       ecx
	cmp       ecx,dword ptr [ebp-8]
	jge       @27
   ;	
   ;					 if (_Local::cmp(beg, 2*i + 1, j) > 0) j = 2*i + 1;
   ;	
	mov       ebx,eax
	mov       dword ptr [ebp-16],edx
	add       ebx,ebx
	mov       ecx,esi
	inc       ebx
	mov       dword ptr [ebp-20],ebx
	mov       ebx,dword ptr [ebp-20]
	add       ebx,ebx
	lea       ebx,dword ptr [ebx+2*ebx]
	add       ebx,ecx
	mov       dword ptr [ebp-24],ebx
	mov       ebx,dword ptr [ebp-16]
	add       ebx,ebx
	lea       ebx,dword ptr [ebx+2*ebx]
	add       ecx,ebx
	mov       dword ptr [ebp-28],ecx
	mov       ecx,dword ptr [ebp-24]
	mov       ebx,dword ptr [ebp-28]
	mov       cx,word ptr [ecx]
	cmp       cx,word ptr [ebx]
	jae       short @29
	or        ecx,-1
	jmp       short @30
@29:
	mov       ecx,dword ptr [ebp-24]
	mov       ebx,dword ptr [ebp-28]
	mov       cx,word ptr [ecx]
	cmp       cx,word ptr [ebx]
	jbe       short @31
	mov       ecx,1
	jmp       short @32
@31:
	xor       ecx,ecx
@32:
@30:
	test      ecx,ecx
	jle       short @28
	mov       edx,eax
	add       edx,edx
	inc       edx
   ;	
   ;					 if (2*i + 2 < m && _Local::cmp(beg, 2*i + 2, j) > 0) j = 2*i + 2;
   ;	
@28:
	mov       ecx,eax
	add       ecx,ecx
	add       ecx,2
	cmp       ecx,dword ptr [ebp-8]
	jge       short @33
	mov       ebx,eax
	mov       dword ptr [ebp-32],edx
	add       ebx,ebx
	mov       ecx,esi
	add       ebx,2
	mov       dword ptr [ebp-36],ebx
	mov       ebx,dword ptr [ebp-36]
	add       ebx,ebx
	lea       ebx,dword ptr [ebx+2*ebx]
	add       ebx,ecx
	mov       dword ptr [ebp-40],ebx
	mov       ebx,dword ptr [ebp-32]
	add       ebx,ebx
	lea       ebx,dword ptr [ebx+2*ebx]
	add       ecx,ebx
	mov       dword ptr [ebp-44],ecx
	mov       ecx,dword ptr [ebp-40]
	mov       ebx,dword ptr [ebp-44]
	mov       cx,word ptr [ecx]
	cmp       cx,word ptr [ebx]
	jae       short @34
	or        ecx,-1
	jmp       short @35
@34:
	mov       ecx,dword ptr [ebp-40]
	mov       ebx,dword ptr [ebp-44]
	mov       cx,word ptr [ecx]
	cmp       cx,word ptr [ebx]
	jbe       short @36
	mov       ecx,1
	jmp       short @37
@36:
	xor       ecx,ecx
@37:
@35:
	test      ecx,ecx
	jle       short @33
	mov       edx,eax
	add       edx,edx
	add       edx,2
   ;	
   ;					 if (i == j) break;
   ;	
@33:
	cmp       edx,eax
	je        short @27
   ;	
   ;					 _Local::swap(beg, i, j);
   ;	
	add       eax,eax
	mov       ebx,edx
	add       ebx,ebx
	mov       ecx,esi
	lea       eax,dword ptr [eax+2*eax]
	add       eax,ecx
	lea       ebx,dword ptr [ebx+2*ebx]
	add       ecx,ebx
	mov       bx,word ptr [eax]
	mov       word ptr [ebp-46],bx
	mov       bx,word ptr [ecx]
	mov       word ptr [eax],bx
	add       eax,2
	mov       bx,word ptr [ebp-46]
	mov       word ptr [ecx],bx
	add       ecx,2
	mov       ebx,dword ptr [eax]
	mov       dword ptr [ebp-52],ebx
	mov       ebx,dword ptr [ecx]
	mov       dword ptr [eax],ebx
	mov       eax,dword ptr [ebp-52]
	mov       dword ptr [ecx],eax
?live16389@256: ; EDX = j, ESI = beg
	jmp       @25
?live16389@272: ; ESI = beg
@27:
	cmp       dword ptr [ebp-8],1
	jg        @21
   ;	
   ;				}
   ;			}
   ;			if (!reverse)
   ;	
@22:
	cmp       byte ptr [ebp+16],0
	jne       short @40
   ;	
   ;			{
   ;				for (k = 0; k < n; k++) _Local::call(beg, k);
   ;	
	xor       edx,edx
	mov       dword ptr [ebp-4],edx
	mov       ecx,dword ptr [ebp-4]
	cmp       ecx,dword ptr [ebp-12]
	jge       short @44
@41:
	mov       eax,dword ptr [ebp-4]
	mov       dword ptr [ebp-56],eax
	mov       dword ptr [ebp-60],esi
	mov       edx,dword ptr [ebp-56]
	add       edx,edx
	lea       edx,dword ptr [edx+2*edx]
	add       edx,dword ptr [ebp-60]
	mov       dword ptr [ebp-64],edx
	mov       ecx,dword ptr [ebp-64]
	call      dword ptr [ecx+2]
	inc       dword ptr [ebp-4]
	mov       eax,dword ptr [ebp-4]
	cmp       eax,dword ptr [ebp-12]
	jl        short @41
   ;	
   ;			}
   ;	
?live16389@320: ; 
	jmp       short @44
   ;	
   ;			else
   ;			{
   ;				for (k = n-1; k >= 0; k--) _Local::call(beg, k);
   ;	
?live16389@336: ; ESI = beg
@40:
	mov       edx,dword ptr [ebp-12]
	dec       edx
	mov       dword ptr [ebp-4],edx
	cmp       dword ptr [ebp-4],0
	jl        short @46
@45:
	mov       ecx,dword ptr [ebp-4]
	mov       dword ptr [ebp-68],ecx
	mov       dword ptr [ebp-72],esi
	mov       eax,dword ptr [ebp-68]
	add       eax,eax
	lea       eax,dword ptr [eax+2*eax]
	add       eax,dword ptr [ebp-72]
	mov       dword ptr [ebp-76],eax
	mov       edx,dword ptr [ebp-76]
	call      dword ptr [edx+2]
	dec       dword ptr [ebp-4]
	cmp       dword ptr [ebp-4],0
	jge       short @45
   ;	
   ;			}
   ;		}
   ;	
?live16389@352: ; 
@46:
@44:
@48:
@19:
	pop       esi
	pop       ebx
	mov       esp,ebp
	pop       ebp
	ret 
@@Menuet@_CallFunctionPriority$qpvt1o	endp
@Menuet@_CallFunctionPriority$qpvt1o	ends
_TEXT	ends
_DATA	segment dword public use32 'DATA'
	align	4
$eecnbaia	label	byte
	dd	3
	dd	3277056
	dd	3277056
	dd	872415231
	dd	-2141167361
	dd	0
	dd	16777024
	dd	0
	dd	0
	dd	0
	dd	-1
	dd	-1
_DATA	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@_CallStart$qppvpvt2	segment virtual
	align	2
@@Menuet@_CallStart$qppvpvt2	proc	near
?live16390@0:
   ;	
   ;		bool _CallStart(TThreadData thread_data, void *init = 0, void *init_end = 0)
   ;	
@49:
	push      ebp
	mov       ebp,esp
	add       esp,-32
	push      ebx
	push      esi
	push      edi
	mov       ebx,dword ptr [ebp+8]
   ;	
   ;		{
   ;			struct _TThreadDataTemplate
   ;			{
   ;				unsigned int data[12];
   ;			};
   ;			static const _TThreadDataTemplate _ThreadDataTemplate =
   ;				{{3, 0x00320100, 0x00320100, 0x33FFFFFF, 0x806060FF, 0x00000000, 0x00FFFF40, 0, 0, 0, -1, -1}};
   ;	
   ;			unsigned int pid = GetPid();
   ;	
?live16390@16: ; EBX = thread_data
	call      @@Menuet@GetPid$qv
	mov       esi,eax
   ;	
   ;			volatile TThreadData *thread_table_item;
   ;			Lock(&_ThreadMutex);
   ;	
?live16390@32: ; EBX = thread_data, ESI = pid
	push      offset @Menuet@_ThreadMutex
	call      @@Menuet@Lock$qp13Menuet@TMutex
	pop       ecx
   ;	
   ;			if (_ExitProcessNow) ExitProcess();
   ;	
	cmp       dword ptr [@Menuet@_ExitProcessNow],0
	je        short @50
	call      @@Menuet@ExitProcess$qv
   ;	
   ;			thread_table_item = &_ThreadTable[_HashByte(pid)];
   ;	
@50:
	push      esi
	call      @@Menuet@_HashByte$qui
	and       eax,255
	pop       ecx
	shl       eax,2
   ;	
   ;			thread_data[MENUET_THREAD_DATA_NEXT] = (void*)*thread_table_item;
   ;			(unsigned int&)thread_data[MENUET_THREAD_DATA_PID] = pid;
   ;			*(_TThreadDataTemplate*)(thread_data + MENUET_THREAD_DATA_FLAG) = _ThreadDataTemplate;
   ;	
?live16390@80: ; EBX = thread_data, EAX = thread_table_item
	lea       edi,dword ptr [ebx+16]
?live16390@96: ; EBX = thread_data, ESI = pid
	add       eax,offset @Menuet@_ThreadTable
?live16390@112: ; EBX = thread_data, EAX = thread_table_item
	mov       ecx,12
?live16390@128: ; EBX = thread_data, ESI = pid, EAX = thread_table_item
	mov       edx,dword ptr [eax]
	mov       dword ptr [ebx+8],edx
	mov       dword ptr [ebx+12],esi
?live16390@160: ; EBX = thread_data, EAX = thread_table_item
	mov       esi,offset $eecnbaia
	rep   movsd
   ;	
   ;			*thread_table_item = thread_data;
   ;	
	mov       dword ptr [eax],ebx
   ;	
   ;			UnLock(&_ThreadMutex);
   ;	
?live16390@192: ; EBX = thread_data
	push      offset @Menuet@_ThreadMutex
	call      @@Menuet@UnLock$qp13Menuet@TMutex
	pop       ecx
   ;	
   ;			if (_ExitProcessNow) ExitProcess();
   ;	
	cmp       dword ptr [@Menuet@_ExitProcessNow],0
	je        short @51
	call      @@Menuet@ExitProcess$qv
   ;	
   ;			_CallFunctionPriority(init, init_end, false);
   ;	
@51:
	push      0
	mov       eax,dword ptr [ebp+16]
	push      eax
	mov       edx,dword ptr [ebp+12]
	push      edx
	call      @@Menuet@_CallFunctionPriority$qpvt1o
	add       esp,12
   ;	
   ;			TStartData start_data;
   ;			_GetStartData(start_data, thread_data);
   ;	
	push      ebx
	lea       ecx,dword ptr [ebp-32]
	push      ecx
	call      @@Menuet@_GetStartData$qr17Menuet@TStartDatappv
	add       esp,8
   ;	
   ;	//		_ApplyCommonColors(start_data.WinData);
   ;			(unsigned int&)thread_data[MENUET_THREAD_DATA_FLAG] |= 0x40000000;
   ;			thread_data[MENUET_THREAD_DATA_TITLE] = (void*)(&start_data);
   ;	
	lea       eax,dword ptr [ebp-32]
	or        dword ptr [ebx+16],1073741824
	mov       dword ptr [ebx+44],eax
   ;	
   ;			if (!MenuetOnStart(start_data, thread_data)) return false;
   ;	
	push      ebx
	lea       edx,dword ptr [ebp-32]
	push      edx
	call      @@MenuetOnStart$qr17Menuet@TStartDatappv
	add       esp,8
	test      al,al
	jne       short @52
	xor       eax,eax
	jmp       short @53
   ;	
   ;			(unsigned int&)thread_data[MENUET_THREAD_DATA_FLAG] &= ~0x40000000;
   ;	
@52:
	and       dword ptr [ebx+16],-1073741825
   ;	
   ;			_SetStartData(start_data, thread_data);
   ;	
	push      ebx
	lea       edx,dword ptr [ebp-32]
	push      edx
	call      @@Menuet@_SetStartData$qrx17Menuet@TStartDatappv
	add       esp,8
   ;	
   ;			return true;
   ;	
?live16390@352: ; 
	mov       al,1
   ;	
   ;		}
   ;	
@54:
@53:
	pop       edi
	pop       esi
	pop       ebx
	mov       esp,ebp
	pop       ebp
	ret 
@@Menuet@_CallStart$qppvpvt2	endp
@Menuet@_CallStart$qppvpvt2	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@_RemoveThreadData$qppvpvt2	segment virtual
	align	2
@@Menuet@_RemoveThreadData$qppvpvt2	proc	near
?live16391@0:
   ;	
   ;		void _RemoveThreadData(TThreadData thread_data, void *exit = 0, void *exit_end = 0)
   ;	
@55:
	push      ebp
	mov       ebp,esp
	push      ebx
	mov       ebx,dword ptr [ebp+8]
   ;	
   ;		{
   ;			_CallFunctionPriority(exit, exit_end, true);
   ;	
?live16391@16: ; EBX = thread_data
	push      1
	mov       eax,dword ptr [ebp+16]
	push      eax
	mov       edx,dword ptr [ebp+12]
	push      edx
	call      @@Menuet@_CallFunctionPriority$qpvt1o
	add       esp,12
   ;	
   ;			volatile TThreadData *thread_table_item;
   ;			Lock(&_ThreadMutex);
   ;	
	push      offset @Menuet@_ThreadMutex
	call      @@Menuet@Lock$qp13Menuet@TMutex
	pop       ecx
   ;	
   ;			if (_ExitProcessNow) ExitProcess();
   ;	
	cmp       dword ptr [@Menuet@_ExitProcessNow],0
	je        short @56
	call      @@Menuet@ExitProcess$qv
   ;	
   ;			thread_table_item = &_ThreadTable[_HashByte(GetPid(thread_data))];
   ;	
@56:
	push      ebx
	call      @@Menuet@GetPid$qppv
	pop       ecx
	push      eax
	call      @@Menuet@_HashByte$qui
	pop       ecx
	and       eax,255
	shl       eax,2
	add       eax,offset @Menuet@_ThreadTable
	jmp       short @58
   ;	
   ;			while (*thread_table_item)
   ;			{
   ;				if (*thread_table_item == thread_data)
   ;	
?live16391@80: ; EAX = thread_table_item, EBX = thread_data
@57:
	cmp       ebx,dword ptr [eax]
	jne       short @59
   ;	
   ;				{
   ;					*thread_table_item = (TThreadData)thread_data[MENUET_THREAD_DATA_NEXT];
   ;	
	mov       edx,dword ptr [ebx+8]
	mov       dword ptr [eax],edx
   ;	
   ;					break;
   ;	
?live16391@112: ; 
	jmp       short @60
   ;	
   ;				}
   ;				thread_table_item = (TThreadData*)(*thread_table_item + MENUET_THREAD_DATA_NEXT);
   ;	
?live16391@128: ; EAX = thread_table_item, EBX = thread_data
@59:
	mov       ecx,dword ptr [eax]
	add       ecx,8
	mov       eax,ecx
@58:
	cmp       dword ptr [eax],0
	jne       short @57
   ;	
   ;			}
   ;			UnLock(&_ThreadMutex);
   ;	
?live16391@160: ; 
@60:
	push      offset @Menuet@_ThreadMutex
	call      @@Menuet@UnLock$qp13Menuet@TMutex
	pop       ecx
   ;	
   ;			if (_ExitProcessNow) ExitProcess();
   ;	
	cmp       dword ptr [@Menuet@_ExitProcessNow],0
	je        short @61
	call      @@Menuet@ExitProcess$qv
   ;	
   ;		}
   ;	
@61:
@62:
	pop       ebx
	pop       ebp
	ret 
@@Menuet@_RemoveThreadData$qppvpvt2	endp
@Menuet@_RemoveThreadData$qppvpvt2	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@GetWindowData$qr18Menuet@TWindowDatappv	segment virtual
	align	2
@@Menuet@GetWindowData$qr18Menuet@TWindowDatappv	proc	near
?live16392@0:
   ;	
   ;		void GetWindowData(TWindowData &win_data, TThreadData thread_data)
   ;	
@63:
	push      ebp
	mov       ebp,esp
	push      esi
	push      edi
	mov       eax,dword ptr [ebp+12]
	mov       edx,dword ptr [ebp+8]
   ;	
   ;		{
   ;			if ((unsigned int)thread_data[MENUET_THREAD_DATA_FLAG] & 0x40000000)
   ;	
?live16392@16: ; EAX = thread_data, EDX = win_data
	test      byte ptr [eax+19],64
	je        short @64
   ;	
   ;			{
   ;				win_data = ((TStartData*)thread_data[MENUET_THREAD_DATA_TITLE])->WinData;
   ;	
	mov       eax,dword ptr [eax+44]
	mov       edi,edx
	mov       ecx,6
	lea       esi,dword ptr [eax+8]
	rep   movsd
   ;	
   ;				return;
   ;	
?live16392@48: ; 
	jmp       short @65
   ;	
   ;			}
   ;			win_data.WindowType = (unsigned short)((unsigned int)thread_data[MENUET_THREAD_DATA_C_WINDOW] >> 24);
   ;	
?live16392@64: ; EAX = thread_data, EDX = win_data
@64:
	mov       ecx,dword ptr [eax+28]
	shr       ecx,24
	mov       word ptr [edx],cx
   ;	
   ;			win_data.HeaderType = (unsigned short)((unsigned int)thread_data[MENUET_THREAD_DATA_C_HEADER] >> 24);
   ;	
	mov       ecx,dword ptr [eax+32]
	shr       ecx,24
	mov       word ptr [edx+2],cx
   ;	
   ;			win_data.WindowColor = (unsigned int)thread_data[MENUET_THREAD_DATA_C_WINDOW] & 0xFFFFFF;
   ;	
	mov       ecx,dword ptr [eax+28]
	and       ecx,16777215
	mov       dword ptr [edx+4],ecx
   ;	
   ;			win_data.HeaderColor = (unsigned int)thread_data[MENUET_THREAD_DATA_C_HEADER] & 0xFFFFFF;
   ;	
	mov       ecx,dword ptr [eax+32]
	and       ecx,16777215
	mov       dword ptr [edx+8],ecx
   ;	
   ;			win_data.BorderColor = (unsigned int)thread_data[MENUET_THREAD_DATA_C_BORDER] & 0xFFFFFF;
   ;	
	mov       ecx,dword ptr [eax+36]
	and       ecx,16777215
	mov       dword ptr [edx+12],ecx
   ;	
   ;			win_data.TitleColor = (unsigned int)thread_data[MENUET_THREAD_DATA_C_TITLE] & 0xFFFFFF;
   ;	
	mov       ecx,dword ptr [eax+40]
	and       ecx,16777215
	mov       dword ptr [edx+16],ecx
   ;	
   ;			win_data.Title = (char*)thread_data[MENUET_THREAD_DATA_TITLE];
   ;	
	mov       eax,dword ptr [eax+44]
	mov       dword ptr [edx+20],eax
   ;	
   ;		}
   ;	
?live16392@176: ; 
@66:
@65:
	pop       edi
	pop       esi
	pop       ebp
	ret 
@@Menuet@GetWindowData$qr18Menuet@TWindowDatappv	endp
@Menuet@GetWindowData$qr18Menuet@TWindowDatappv	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@SetWindowData$qrx18Menuet@TWindowDatappv	segment virtual
	align	2
@@Menuet@SetWindowData$qrx18Menuet@TWindowDatappv	proc	near
?live16393@0:
   ;	
   ;		void SetWindowData(const TWindowData &win_data, TThreadData thread_data)
   ;	
@67:
	push      ebp
	mov       ebp,esp
	push      ebx
	push      esi
	push      edi
	mov       edx,dword ptr [ebp+12]
	mov       eax,dword ptr [ebp+8]
   ;	
   ;		{
   ;			if ((unsigned int)thread_data[MENUET_THREAD_DATA_FLAG] & 0x40000000)
   ;	
?live16393@16: ; EAX = win_data, EDX = thread_data
	test      byte ptr [edx+19],64
	je        short @68
   ;	
   ;			{
   ;				((TStartData*)thread_data[MENUET_THREAD_DATA_TITLE])->WinData = win_data;
   ;	
	mov       edx,dword ptr [edx+44]
	mov       esi,eax
	mov       ecx,6
	lea       edi,dword ptr [edx+8]
	rep   movsd
   ;	
   ;				return;
   ;	
?live16393@48: ; 
	jmp       short @69
   ;	
   ;			}
   ;			(unsigned int&)thread_data[MENUET_THREAD_DATA_C_WINDOW] =
   ;	
?live16393@64: ; EAX = win_data, EDX = thread_data
@68:
	movzx     ecx,word ptr [eax]
	shl       ecx,24
	mov       ebx,dword ptr [eax+4]
	and       ebx,16777215
	or        ecx,ebx
	mov       dword ptr [edx+28],ecx
   ;	
   ;						((unsigned int)win_data.WindowType << 24) | (win_data.WindowColor & 0xFFFFFF);
   ;			(unsigned int&)thread_data[MENUET_THREAD_DATA_C_HEADER] =
   ;	
	movzx     ecx,word ptr [eax+2]
	shl       ecx,24
	mov       ebx,dword ptr [eax+8]
	and       ebx,16777215
	or        ecx,ebx
	mov       dword ptr [edx+32],ecx
   ;	
   ;						((unsigned int)win_data.HeaderType << 24) | (win_data.HeaderColor & 0xFFFFFF);
   ;			(unsigned int&)thread_data[MENUET_THREAD_DATA_C_BORDER] = win_data.BorderColor & 0xFFFFFF;
   ;	
	mov       ecx,dword ptr [eax+12]
	and       ecx,16777215
	mov       dword ptr [edx+36],ecx
   ;	
   ;			(unsigned int&)thread_data[MENUET_THREAD_DATA_C_TITLE] = win_data.TitleColor & 0xFFFFFF;
   ;	
	mov       ecx,dword ptr [eax+16]
	and       ecx,16777215
	mov       dword ptr [edx+40],ecx
   ;	
   ;			thread_data[MENUET_THREAD_DATA_TITLE] = (void*)win_data.Title;
   ;	
	mov       eax,dword ptr [eax+20]
	mov       dword ptr [edx+44],eax
   ;	
   ;			Invalidate(1, thread_data);
   ;	
?live16393@144: ; EDX = thread_data
	push      edx
	push      1
	call      @@Menuet@Invalidate$qippv
	add       esp,8
   ;	
   ;		}
   ;	
?live16393@160: ; 
@70:
@69:
	pop       edi
	pop       esi
	pop       ebx
	pop       ebp
	ret 
@@Menuet@SetWindowData$qrx18Menuet@TWindowDatappv	endp
@Menuet@SetWindowData$qrx18Menuet@TWindowDatappv	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@CloseWindow$qppv	segment virtual
	align	2
@@Menuet@CloseWindow$qppv	proc	near
?live16394@0:
   ;	
   ;		void CloseWindow(TThreadData thread_data)
   ;	
@71:
	push      ebp
	mov       ebp,esp
   ;	
   ;		{
   ;			(unsigned int&)thread_data[MENUET_THREAD_DATA_FLAG] |= 0x80000000;
   ;	
	mov       eax,dword ptr [ebp+8]
	or        dword ptr [eax+16],-2147483648
   ;	
   ;		}
   ;	
@72:
	pop       ebp
	ret 
@@Menuet@CloseWindow$qppv	endp
@Menuet@CloseWindow$qppv	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@Invalidate$qippv	segment virtual
	align	2
@@Menuet@Invalidate$qippv	proc	near
?live16395@0:
   ;	
   ;		void Invalidate(int frame, TThreadData thread_data)
   ;	
@73:
	push      ebp
	mov       ebp,esp
	mov       eax,dword ptr [ebp+8]
   ;	
   ;		{
   ;			if (frame < 0) return;
   ;	
?live16395@16: ; EAX = frame
	test      eax,eax
	jl        short @75
   ;	
   ;			(unsigned int&)thread_data[MENUET_THREAD_DATA_FLAG] |= (frame ? 3 : 1);
   ;	
	test      eax,eax
	je        short @76
	mov       eax,3
	jmp       short @77
@76:
	mov       eax,1
@77:
	mov       edx,dword ptr [ebp+12]
	or        dword ptr [edx+16],eax
   ;	
   ;		}
   ;	
?live16395@48: ; 
@78:
@75:
	pop       ebp
	ret 
@@Menuet@Invalidate$qippv	endp
@Menuet@Invalidate$qippv	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@GetPicture$qrust1ppv	segment virtual
	align	2
@@Menuet@GetPicture$qrust1ppv	proc	near
?live16396@0:
   ;	
   ;		void* GetPicture(unsigned short &width, unsigned short &height, TThreadData thread_data)
   ;	
@79:
	push      ebp
	mov       ebp,esp
	mov       eax,dword ptr [ebp+16]
   ;	
   ;		{
   ;			width = (unsigned short)((unsigned int)thread_data[MENUET_THREAD_DATA_SZ_PICT] >> 16);
   ;	
?live16396@16: ; EAX = thread_data
	mov       ecx,dword ptr [ebp+8]
	mov       edx,dword ptr [eax+52]
	shr       edx,16
	mov       word ptr [ecx],dx
   ;	
   ;			height = (unsigned short)((unsigned int)thread_data[MENUET_THREAD_DATA_SZ_PICT]);
   ;	
	mov       cx,word ptr [eax+52]
	mov       edx,dword ptr [ebp+12]
	mov       word ptr [edx],cx
   ;	
   ;			return (void*)thread_data[MENUET_THREAD_DATA_PICTURE];
   ;	
	mov       eax,dword ptr [eax+48]
   ;	
   ;		}
   ;	
?live16396@64: ; 
@81:
@80:
	pop       ebp
	ret 
@@Menuet@GetPicture$qrust1ppv	endp
@Menuet@GetPicture$qrust1ppv	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@SetPicture$qpvususppv	segment virtual
	align	2
@@Menuet@SetPicture$qpvususppv	proc	near
?live16397@0:
   ;	
   ;		void SetPicture(void *picture, unsigned short width, unsigned short height, TThreadData thread_data)
   ;	
@82:
	push      ebp
	mov       ebp,esp
	push      ebx
	mov       eax,dword ptr [ebp+20]
	mov       ecx,dword ptr [ebp+16]
	mov       edx,dword ptr [ebp+12]
   ;	
   ;		{
   ;			thread_data[MENUET_THREAD_DATA_PICTURE] = (void*)picture;
   ;	
?live16397@16: ; EAX = thread_data, EDX = width, ECX = height
	mov       ebx,dword ptr [ebp+8]
	mov       dword ptr [eax+48],ebx
   ;	
   ;			(unsigned int&)thread_data[MENUET_THREAD_DATA_SZ_PICT] =
   ;	
	test      dx,dx
	je        short @85
	test      cx,cx
	jne       short @83
@85:
	xor       ebx,ebx
	jmp       short @84
@83:
	movzx     ebx,dx
	shl       ebx,16
	movzx     edx,cx
	or        ebx,edx
@84:
	mov       dword ptr [eax+52],ebx
   ;	
   ;						(width == 0 || height == 0) ? 0 : (((unsigned int)width << 16) | height);
   ;			Invalidate(0, thread_data);
   ;	
?live16397@48: ; EAX = thread_data
	push      eax
	push      0
	call      @@Menuet@Invalidate$qippv
	add       esp,8
   ;	
   ;		}
   ;	
?live16397@64: ; 
@86:
	pop       ebx
	pop       ebp
	ret 
@@Menuet@SetPicture$qpvususppv	endp
@Menuet@SetPicture$qpvususppv	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@GetBorderHeader$qrust1ppv	segment virtual
	align	2
@@Menuet@GetBorderHeader$qrust1ppv	proc	near
?live16398@0:
   ;	
   ;		void GetBorderHeader(unsigned short &border_size, unsigned short &header_size, TThreadData thread_data)
   ;	
@87:
	push      ebp
	mov       ebp,esp
	push      ebx
	mov       eax,dword ptr [ebp+16]
   ;	
   ;		{
   ;			int win_type = ((unsigned int)thread_data[MENUET_THREAD_DATA_FLAG] & 0x40000000) ?
   ;	
?live16398@16: ; EAX = thread_data
	test      byte ptr [eax+19],64
	je        short @88
	mov       edx,dword ptr [eax+44]
	movzx     ebx,word ptr [edx+8]
	jmp       short @89
@88:
	mov       ebx,dword ptr [eax+28]
	shr       ebx,24
   ;	
   ;				((TStartData*)thread_data[MENUET_THREAD_DATA_TITLE])->WinData.WindowType :
   ;			   ((unsigned int)thread_data[MENUET_THREAD_DATA_C_WINDOW] >> 24);
   ;			border_size = MENUET_BORDER_SIZE;
   ;	
?live16398@32: ; EBX = win_type
@89:
	mov       eax,dword ptr [ebp+8]
   ;	
   ;			header_size = short(((win_type & 15) == 3) ? _GetSkinHeader() : MENUET_HEADER_SIZE);
   ;	
	and       ebx,15
	cmp       ebx,3
	mov       word ptr [eax],4
	jne       short @90
	call      @@Menuet@_GetSkinHeader$qv
	jmp       short @91
@90:
	mov       ax,20
@91:
	mov       edx,dword ptr [ebp+12]
	mov       word ptr [edx],ax
   ;	
   ;		}
   ;	
?live16398@96: ; 
@92:
	pop       ebx
	pop       ebp
	ret 
@@Menuet@GetBorderHeader$qrust1ppv	endp
@Menuet@GetBorderHeader$qrust1ppv	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@GetClientSize$qrust1iippv	segment virtual
	align	2
@@Menuet@GetClientSize$qrust1iippv	proc	near
?live16399@0:
   ;	
   ;		void GetClientSize(unsigned short &width, unsigned short &height,
   ;	
@93:
	push      ebp
	mov       ebp,esp
	push      ecx
	push      ebx
	push      esi
   ;	
   ;							int win_width, int win_height, TThreadData thread_data)
   ;		{
   ;			const int MAX_SIZE = 32767;
   ;			unsigned short border_size, header_size;
   ;			GetBorderHeader(border_size, header_size, thread_data);
   ;	
?live16399@16: ; EBX = win_width, ESI = win_height
	lea       edx,dword ptr [ebp-4]
?live16399@32: ; 
	mov       esi,dword ptr [ebp+20]
	mov       ebx,dword ptr [ebp+16]
?live16399@48: ; EBX = win_width, ESI = win_height
	mov       eax,dword ptr [ebp+24]
	lea       ecx,dword ptr [ebp-2]
	push      eax
	push      edx
	push      ecx
	call      @@Menuet@GetBorderHeader$qrust1ppv
   ;	
   ;			win_width -= 2 * border_size;
   ;	
	movzx     eax,word ptr [ebp-2]
   ;	
   ;			win_height -= border_size + header_size;
   ;	
?live16399@80: ; EBX = win_width, ESI = win_height, EAX = @temp2
	movzx     ecx,word ptr [ebp-4]
?live16399@96: ; EBX = win_width, ESI = win_height
	mov       edx,eax
?live16399@112: ; EBX = win_width, ESI = win_height, EAX = @temp2
	add       eax,ecx
?live16399@128: ; EBX = win_width, ESI = win_height
	add       edx,edx
?live16399@144: ; EBX = win_width, ESI = win_height, EAX = @temp2
	sub       esi,eax
?live16399@160: ; EBX = win_width, ESI = win_height
	sub       ebx,edx
	add       esp,12
   ;	
   ;			if (win_width < 0) win_width = 0;
   ;	
	test      ebx,ebx
	jge       short @94
	xor       ebx,ebx
	jmp       short @95
   ;	
   ;			else if (win_width > MAX_SIZE) win_width = MAX_SIZE;
   ;	
@94:
	cmp       ebx,32767
	jle       short @96
	mov       ebx,32767
   ;	
   ;			if (win_height < 0) win_height = 0;
   ;	
@96:
@95:
	test      esi,esi
	jge       short @97
	xor       esi,esi
	jmp       short @98
   ;	
   ;			else if (win_height > MAX_SIZE) win_height = MAX_SIZE;
   ;	
@97:
	cmp       esi,32767
	jle       short @99
	mov       esi,32767
   ;	
   ;			width = (unsigned short)win_width;
   ;	
@99:
@98:
	mov       eax,dword ptr [ebp+8]
	mov       word ptr [eax],bx
   ;	
   ;			height = (unsigned short)win_height;
   ;	
?live16399@272: ; ESI = win_height
	mov       edx,dword ptr [ebp+12]
	mov       word ptr [edx],si
   ;	
   ;		}
   ;	
?live16399@288: ; 
@100:
	pop       esi
	pop       ebx
	pop       ecx
	pop       ebp
	ret 
@@Menuet@GetClientSize$qrust1iippv	endp
@Menuet@GetClientSize$qrust1iippv	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@GetMousePosPicture$qrst1	segment virtual
	align	2
@@Menuet@GetMousePosPicture$qrst1	proc	near
?live16400@0:
   ;	
   ;		void GetMousePosPicture(short &x, short &y)
   ;	
@101:
	push      ebp
	mov       ebp,esp
	push      ecx
	push      ebx
	push      esi
	mov       esi,dword ptr [ebp+12]
	mov       ebx,dword ptr [ebp+8]
   ;	
   ;		{
   ;			unsigned short dx, dy;
   ;			GetMousePosition(x, y);
   ;	
?live16400@16: ; EBX = x, ESI = y
	push      0
	push      esi
	push      ebx
	call      @@Menuet@GetMousePosition$qrst1o
	add       esp,12
   ;	
   ;			GetBorderHeader(dx, dy);
   ;	
	call      @@Menuet@GetThreadData$qv
	push      eax
	lea       eax,dword ptr [ebp-4]
	push      eax
	lea       edx,dword ptr [ebp-2]
	push      edx
	call      @@Menuet@GetBorderHeader$qrust1ppv
   ;	
   ;			x -= dx; y -= dy;
   ;	
	mov       cx,word ptr [ebp-2]
	sub       word ptr [ebx],cx
	add       esp,12
	mov       ax,word ptr [ebp-4]
	sub       word ptr [esi],ax
   ;	
   ;		}
   ;	
?live16400@96: ; 
@102:
	pop       esi
	pop       ebx
	pop       ecx
	pop       ebp
	ret 
@@Menuet@GetMousePosPicture$qrst1	endp
@Menuet@GetMousePosPicture$qrst1	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@MemoryHeap@_FirstNotZeroBit$qui	segment virtual
	align	2
@@MemoryHeap@_FirstNotZeroBit$qui	proc	near
?live16401@0:
   ;	
   ;		TMemItem _FirstNotZeroBit(TMemItem i)
   ;	
@103:
	push      ebp
	mov       ebp,esp
	mov       edx,dword ptr [ebp+8]
   ;	
   ;		{
   ;			TMemItem r = 0;
   ;	
?live16401@16: ; EDX = i
	xor       eax,eax
	jmp       short @105
   ;	
   ;			while ((i >>= 1) != 0) r++;
   ;	
?live16401@32: ; EAX = r, EDX = i
@104:
	inc       eax
@105:
	shr       edx,1
	jne       short @104
   ;	
   ;			return r;
   ;		}
   ;	
?live16401@48: ; 
@107:
@106:
	pop       ebp
	ret 
@@MemoryHeap@_FirstNotZeroBit$qui	endp
@MemoryHeap@_FirstNotZeroBit$qui	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@MemoryHeap@_RBTreeRotate$quiuii	segment virtual
	align	2
@@MemoryHeap@_RBTreeRotate$quiuii	proc	near
?live16402@0:
   ;	
   ;		void _RBTreeRotate(TMemItem parent, TMemItem item, int side)
   ;	
@108:
	push      ebp
	mov       ebp,esp
	push      ebx
	push      esi
	mov       ecx,dword ptr [ebp+12]
	mov       edx,dword ptr [ebp+8]
   ;	
   ;		{
   ;			TMemItem temp = MEMORY_HEAP_ITEM(parent,0);
   ;	
?live16402@16: ; EDX = parent, ECX = item
	mov       eax,dword ptr [edx]
   ;	
   ;			MEMORY_HEAP_ITEM(item,0) = temp;
   ;	
?live16402@32: ; EAX = temp, EDX = parent, ECX = item
	mov       dword ptr [ecx],eax
   ;	
   ;			if (temp)
   ;	
	test      eax,eax
	je        short @110
   ;	
   ;			{
   ;				if (MEMORY_HEAP_ITEM(temp,2) == parent)
   ;	
	mov       ebx,eax
	cmp       edx,dword ptr [ebx+8]
	jne       short @111
   ;	
   ;				{
   ;					MEMORY_HEAP_ITEM(temp,2) = item;
   ;	
?live16402@80: ; EAX = temp, EDX = parent, ECX = item, EBX = @temp7
	mov       dword ptr [ebx+8],ecx
   ;	
   ;				}
   ;	
?live16402@96: ; EDX = parent, ECX = item
	jmp       short @112
   ;	
   ;				else MEMORY_HEAP_ITEM(temp,3) = item;
   ;	
?live16402@112: ; EAX = temp, EDX = parent, ECX = item
@111:
	mov       dword ptr [eax+12],ecx
   ;	
   ;			}
   ;			temp = MEMORY_HEAP_ITEM(item,side^1);
   ;	
?live16402@128: ; EDX = parent, ECX = item
@112:
@110:
	mov       eax,dword ptr [ebp+16]
	xor       eax,1
	mov       eax,dword ptr [ecx+4*eax]
   ;	
   ;			if (temp) MEMORY_HEAP_ITEM(temp,0) = parent;
   ;	
?live16402@144: ; EAX = temp, EDX = parent, ECX = item
	test      eax,eax
	je        short @113
	mov       dword ptr [eax],edx
   ;	
   ;			MEMORY_HEAP_ITEM(parent,side) = temp;
   ;	
@113:
	mov       ebx,edx
	mov       esi,dword ptr [ebp+16]
	mov       dword ptr [ebx+4*esi],eax
   ;	
   ;			MEMORY_HEAP_ITEM(parent,0) = item;
   ;	
?live16402@176: ; EDX = parent, ECX = item, EBX = @temp3
	mov       dword ptr [ebx],ecx
   ;	
   ;			MEMORY_HEAP_ITEM(item,side^1) = parent;
   ;	
	mov       eax,dword ptr [ebp+16]
	xor       eax,1
	mov       dword ptr [ecx+4*eax],edx
   ;	
   ;			temp = MEMORY_HEAP_ITEM(parent,1);
   ;	
	mov       eax,dword ptr [ebx+4]
   ;	
   ;			MEMORY_HEAP_ITEM(parent,1) = MEMORY_HEAP_ITEM(item,1);
   ;	
?live16402@224: ; EAX = temp, EDX = parent, ECX = item, EBX = @temp3
	mov       esi,dword ptr [ecx+4]
	mov       dword ptr [ebx+4],esi
   ;	
   ;			MEMORY_HEAP_ITEM(item,1) = temp;
   ;	
?live16402@240: ; EAX = temp, ECX = item
	mov       dword ptr [ecx+4],eax
   ;	
   ;		}
   ;	
?live16402@256: ; 
@114:
	pop       esi
	pop       ebx
	pop       ebp
	ret 
@@MemoryHeap@_RBTreeRotate$quiuii	endp
@MemoryHeap@_RBTreeRotate$quiuii	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@MemoryHeap@InitFreeSpace$qr21MemoryHeap@TFreeSpace	segment virtual
	align	2
@@MemoryHeap@InitFreeSpace$qr21MemoryHeap@TFreeSpace	proc	near
?live16403@0:
   ;	
   ;		void InitFreeSpace(TFreeSpace &fs)
   ;	
@115:
	push      ebp
	mov       ebp,esp
	push      ebx
	mov       ecx,dword ptr [ebp+8]
   ;	
   ;		{
   ;			TMemItem i;
   ;			for (i = 0; i <= NumTreeSmall; i++) fs.Small[i] = 0;
   ;	
?live16403@16: ; ECX = fs
	xor       edx,edx
	mov       eax,ecx
@116:
	xor       ebx,ebx
	inc       edx
	mov       dword ptr [eax],ebx
	add       eax,4
	cmp       edx,32
	jbe       short @116
   ;	
   ;			fs.Min = 0; fs.SmallMask = 0;
   ;	
	xor       eax,eax
	xor       edx,edx
	mov       dword ptr [ecx+128],eax
	mov       dword ptr [ecx+132],edx
   ;	
   ;		}
   ;	
?live16403@48: ; 
@119:
	pop       ebx
	pop       ebp
	ret 
@@MemoryHeap@InitFreeSpace$qr21MemoryHeap@TFreeSpace	endp
@MemoryHeap@InitFreeSpace$qr21MemoryHeap@TFreeSpace	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@MemoryHeap@_FreeAdd$qr21MemoryHeap@TFreeSpaceui	segment virtual
	align	2
@@MemoryHeap@_FreeAdd$qr21MemoryHeap@TFreeSpaceui	proc	near
?live16404@0:
   ;	
   ;		void _FreeAdd(TFreeSpace &fs, TMemItem item)
   ;	
@120:
	push      ebp
	mov       ebp,esp
	push      ecx
	push      ebx
	push      esi
	push      edi
	mov       esi,dword ptr [ebp+12]
	mov       edx,dword ptr [ebp+8]
   ;	
   ;		{
   ;			TMemItem size = MEMORY_HEAP_NEXT(item) - item;
   ;	
?live16404@16: ; ESI = item, EDX = fs
	mov       ebx,dword ptr [esi-4]
	sub       ebx,esi
   ;	
   ;			if (size < MemAddSize + MemMinSize + MemAlign * NumTreeSmall)
   ;	
?live16404@32: ; ESI = item, EBX = size, EDX = fs
	cmp       ebx,144
	jae       short @121
   ;	
   ;			{
   ;				TMemItem s = (size - (MemAddSize + MemMinSize)) / MemAlign;
   ;	
@122:
	sub       ebx,16
	shr       ebx,2
   ;	
   ;				TMemItem &addto = fs.Small[s];
   ;	
?live16404@64: ; ESI = item, EDX = fs, EBX = s
	mov       eax,ebx
	shl       eax,2
	add       eax,edx
   ;	
   ;				MEMORY_HEAP_ITEM(item,1) = (TMemItem)(&addto);
   ;	
?live16404@80: ; ESI = item, EDX = fs, EAX = addto, EBX = s
	mov       dword ptr [esi+4],eax
   ;	
   ;				MEMORY_HEAP_ITEM(item,0) = (TMemItem)addto;
   ;	
	mov       ecx,dword ptr [eax]
	mov       dword ptr [esi],ecx
   ;	
   ;				if (addto) MEMORY_HEAP_ITEM(addto,1) = item;
   ;	
	cmp       dword ptr [eax],0
	je        short @123
	mov       ecx,dword ptr [eax]
	mov       dword ptr [ecx+4],esi
   ;	
   ;				addto = item;
   ;	
@123:
	mov       dword ptr [eax],esi
   ;	
   ;				fs.SmallMask |= TMemItem(1) << s;
   ;	
?live16404@144: ; EDX = fs, EBX = s
	mov       ecx,ebx
	mov       eax,1
	shl       eax,cl
	or        dword ptr [edx+132],eax
   ;	
   ;				return;
   ;	
?live16404@160: ; 
	jmp       @124
   ;	
   ;			}
   ;			TMemItem addto = fs.Min, parent, temp;
   ;	
?live16404@176: ; ESI = item, EBX = size, EDX = fs
@125:
@121:
	mov       eax,dword ptr [edx+128]
   ;	
   ;			MEMORY_HEAP_ITEM(item,2) = 0;
   ;	
?live16404@192: ; EAX = addto, ESI = item, EBX = size, EDX = fs
	mov       ecx,esi
	xor       edi,edi
	mov       dword ptr [ecx+8],edi
   ;	
   ;			MEMORY_HEAP_ITEM(item,3) = 0;
   ;	
?live16404@208: ; EAX = addto, ESI = item, EBX = size, EDX = fs, ECX = @temp11
	xor       edi,edi
	mov       dword ptr [ecx+12],edi
   ;	
   ;			if (!addto)
   ;	
	test      eax,eax
	jne       short @126
   ;	
   ;			{
   ;				MEMORY_HEAP_ITEM(item,0) = 0;
   ;	
?live16404@240: ; ESI = item, EDX = fs, ECX = @temp11
	xor       eax,eax
	mov       dword ptr [ecx],eax
   ;	
   ;				MEMORY_HEAP_ITEM(item,1) = 1;
   ;	
	mov       dword ptr [ecx+4],1
   ;	
   ;				fs.Min = item;
   ;	
?live16404@272: ; ESI = item, EDX = fs
	mov       dword ptr [edx+128],esi
   ;	
   ;				return;
   ;	
?live16404@288: ; 
	jmp       @124
   ;	
   ;			}
   ;			MEMORY_HEAP_ITEM(item,1) = 0;
   ;	
?live16404@304: ; EAX = addto, ESI = item, EBX = size, EDX = fs
@126:
	xor       ecx,ecx
	mov       dword ptr [esi+4],ecx
   ;	
   ;			TMemItem side = 2;
   ;	
	mov       dword ptr [ebp-4],2
   ;	
   ;			if (MEMORY_HEAP_NEXT(addto) - addto >= size) fs.Min = item;
   ;	
	mov       ecx,dword ptr [eax-4]
	sub       ecx,eax
	cmp       ebx,ecx
	ja        short @127
	mov       dword ptr [edx+128],esi
	jmp       short @128
   ;	
   ;			else
   ;			{
   ;				for (;;)
   ;				{
   ;					parent = MEMORY_HEAP_ITEM(addto,0);
   ;	
?live16404@352: ; EAX = addto, ESI = item, EBX = size
@127:
@129:
	mov       ecx,dword ptr [eax]
   ;	
   ;					if (!parent) break;
   ;	
?live16404@368: ; EAX = addto, ECX = parent, ESI = item, EBX = size
	test      ecx,ecx
	je        short @131
   ;	
   ;					if (MEMORY_HEAP_NEXT(parent) - parent < size) addto = parent;
   ;	
	mov       edx,dword ptr [ecx-4]
	sub       edx,ecx
	cmp       ebx,edx
	jbe       short @131
	mov       eax,ecx
?live16404@400: ; EAX = addto, ESI = item, EBX = size
	jmp       short @129
   ;	
   ;					else break;
   ;				}
   ;				for (;;)
   ;				{
   ;					if (MEMORY_HEAP_NEXT(addto) - addto < size)
   ;	
@131:
@135:
	mov       edx,eax
	mov       ecx,dword ptr [edx-4]
	sub       ecx,eax
	cmp       ebx,ecx
	jbe       short @136
   ;	
   ;					{
   ;						temp = MEMORY_HEAP_ITEM(addto,3);
   ;	
?live16404@432: ; EAX = addto, ESI = item, EBX = size, EDX = @temp8
	mov       edx,dword ptr [edx+12]
   ;	
   ;						if (!temp) {side = 3; break;}
   ;	
?live16404@448: ; EAX = addto, EDX = temp, ESI = item, EBX = size
	test      edx,edx
	jne       short @137
	mov       dword ptr [ebp-4],3
	jmp       short @138
   ;	
   ;						addto = temp;
   ;	
?live16404@464: ; EDX = temp, ESI = item, EBX = size
@137:
	mov       eax,edx
   ;	
   ;					}
   ;	
?live16404@480: ; EAX = addto, ESI = item, EBX = size
	jmp       short @135
   ;	
   ;					else
   ;					{
   ;						temp = MEMORY_HEAP_ITEM(addto,2);
   ;	
@136:
	mov       edx,dword ptr [eax+8]
   ;	
   ;						if (!temp) break;
   ;	
?live16404@512: ; EAX = addto, EDX = temp, ESI = item, EBX = size
	test      edx,edx
	je        short @138
   ;	
   ;						addto = temp;
   ;	
?live16404@528: ; EDX = temp, ESI = item, EBX = size
	mov       eax,edx
?live16404@544: ; EAX = addto, ESI = item, EBX = size
	jmp       short @135
   ;	
   ;					}
   ;				}
   ;			}
   ;			MEMORY_HEAP_ITEM(item,0) = addto;
   ;	
?live16404@560: ; EAX = addto, ESI = item
@138:
@128:
	mov       dword ptr [esi],eax
   ;	
   ;			MEMORY_HEAP_ITEM(addto,side) = item;
   ;	
	mov       ecx,dword ptr [ebp-4]
	mov       dword ptr [eax+4*ecx],esi
   ;	
   ;			for (;;)
   ;			{
   ;				if (MEMORY_HEAP_ITEM(addto,1) != 0) return;
   ;	
@142:
	mov       edx,eax
	cmp       dword ptr [edx+4],0
	jne       @124
   ;	
   ;				parent = MEMORY_HEAP_ITEM(addto,0);
   ;	
?live16404@608: ; EAX = addto, ESI = item, EDX = @temp6
	mov       ecx,dword ptr [edx]
   ;	
   ;				temp = MEMORY_HEAP_ITEM(parent,2);
   ;	
?live16404@624: ; EAX = addto, ECX = parent, ESI = item
	mov       ebx,ecx
	mov       edx,dword ptr [ebx+8]
   ;	
   ;				if (temp == addto)
   ;	
?live16404@640: ; EAX = addto, EDX = temp, ECX = parent, ESI = item, EBX = @temp9
	;	
	cmp       eax,edx
	jne       short @144
   ;	
   ;				{
   ;					temp = MEMORY_HEAP_ITEM(parent,3);
   ;	
?live16404@656: ; EAX = addto, ECX = parent, ESI = item, EBX = @temp9
	mov       edx,dword ptr [ebx+12]
   ;	
   ;					side = 2;
   ;	
?live16404@672: ; EAX = addto, EDX = temp, ECX = parent, ESI = item
	mov       dword ptr [ebp-4],2
   ;	
   ;				}
   ;	
	jmp       short @145
   ;	
   ;				else side = 3;
   ;	
@144:
	mov       dword ptr [ebp-4],3
   ;	
   ;				if (!temp || MEMORY_HEAP_ITEM(temp,1) != 0) break;
   ;	
@145:
	test      edx,edx
	je        short @148
	cmp       dword ptr [edx+4],0
	jne       short @148
   ;	
   ;				MEMORY_HEAP_ITEM(addto,1) = 1;
   ;	
?live16404@736: ; EAX = addto, EDX = temp, ECX = parent
	mov       dword ptr [eax+4],1
   ;	
   ;				MEMORY_HEAP_ITEM(temp,1) = 1;
   ;	
?live16404@752: ; EDX = temp, ECX = parent
	mov       dword ptr [edx+4],1
   ;	
   ;				item = parent;
   ;	
?live16404@768: ; ECX = parent
	mov       esi,ecx
   ;	
   ;				addto = MEMORY_HEAP_ITEM(item,0);
   ;	
?live16404@784: ; ESI = item
	mov       edx,esi
	mov       eax,dword ptr [edx]
   ;	
   ;				if (!addto) return;
   ;	
?live16404@800: ; EAX = addto, ESI = item, EDX = @temp7
	test      eax,eax
	je        short @124
   ;	
   ;				MEMORY_HEAP_ITEM(item,1) = 0;
   ;	
	xor       ecx,ecx
	mov       dword ptr [edx+4],ecx
?live16404@832: ; EAX = addto, ESI = item
	jmp       short @142
   ;	
   ;			}
   ;			if (MEMORY_HEAP_ITEM(addto,side) != item)
   ;	
?live16404@848: ; EAX = addto, ECX = parent, ESI = item
@148:
	mov       edx,dword ptr [ebp-4]
	cmp       esi,dword ptr [eax+4*edx]
	je        short @151
   ;	
   ;			{
   ;				temp = MEMORY_HEAP_ITEM(item,side);
   ;	
	mov       edx,dword ptr [ebp-4]
	mov       edx,dword ptr [esi+4*edx]
   ;	
   ;				if (temp) MEMORY_HEAP_ITEM(temp,0) = addto;
   ;	
?live16404@880: ; EAX = addto, EDX = temp, ECX = parent, ESI = item
	test      edx,edx
	je        short @152
	mov       dword ptr [edx],eax
   ;	
   ;				MEMORY_HEAP_ITEM(addto,side^1) = temp;
   ;	
@152:
	mov       ebx,dword ptr [ebp-4]
	xor       ebx,1
	mov       dword ptr [eax+4*ebx],edx
   ;	
   ;				MEMORY_HEAP_ITEM(addto,0) = item;
   ;	
?live16404@912: ; EAX = addto, ECX = parent, ESI = item
	mov       dword ptr [eax],esi
   ;	
   ;				MEMORY_HEAP_ITEM(item,side) = addto;
   ;	
	mov       edx,dword ptr [ebp-4]
	mov       dword ptr [esi+4*edx],eax
   ;	
   ;				MEMORY_HEAP_ITEM(item,0) = parent;
   ;	
?live16404@944: ; ECX = parent, ESI = item
	mov       dword ptr [esi],ecx
   ;	
   ;				MEMORY_HEAP_ITEM(parent,side) = item;
   ;	
	mov       eax,dword ptr [ebp-4]
	mov       dword ptr [ecx+4*eax],esi
   ;	
   ;			}
   ;	
	jmp       short @153
   ;	
   ;			else item = addto;
   ;	
?live16404@992: ; EAX = addto, ECX = parent
@151:
	mov       esi,eax
   ;	
   ;			_RBTreeRotate(parent, item, side);
   ;	
?live16404@1008: ; ECX = parent, ESI = item
@153:
	mov       eax,dword ptr [ebp-4]
	push      eax
	push      esi
	push      ecx
	call      @@MemoryHeap@_RBTreeRotate$quiuii
	add       esp,12
   ;	
   ;		}
   ;	
?live16404@1024: ; 
@154:
@124:
	pop       edi
	pop       esi
	pop       ebx
	pop       ecx
	pop       ebp
	ret 
@@MemoryHeap@_FreeAdd$qr21MemoryHeap@TFreeSpaceui	endp
@MemoryHeap@_FreeAdd$qr21MemoryHeap@TFreeSpaceui	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@MemoryHeap@_FreeDel$qr21MemoryHeap@TFreeSpaceui	segment virtual
	align	2
@@MemoryHeap@_FreeDel$qr21MemoryHeap@TFreeSpaceui	proc	near
?live16405@0:
   ;	
   ;		void _FreeDel(TFreeSpace &fs, TMemItem item)
   ;	
@155:
	push      ebp
	mov       ebp,esp
	add       esp,-8
	push      ebx
	push      esi
	push      edi
	mov       eax,dword ptr [ebp+12]
	mov       edx,dword ptr [ebp+8]
   ;	
   ;		{
   ;			TMemItem size = MEMORY_HEAP_NEXT(item) - item;
   ;	
?live16405@16: ; EAX = item, EDX = fs
	mov       esi,eax
	mov       ecx,dword ptr [esi-4]
	sub       ecx,eax
   ;	
   ;			if (size < MemAddSize + MemMinSize + MemAlign * NumTreeSmall)
   ;	
?live16405@32: ; EAX = item, EDX = fs, ECX = size, ESI = @temp12
	cmp       ecx,144
	jae       short @157
   ;	
   ;			{
   ;				TMemItem prev = MEMORY_HEAP_ITEM(item,1);
   ;	
@158:
	mov       ebx,dword ptr [esi+4]
   ;	
   ;				TMemItem next = MEMORY_HEAP_ITEM(item,0);
   ;	
?live16405@64: ; EAX = item, EDX = fs, ECX = size, ESI = @temp12, EBX = prev
	mov       eax,dword ptr [esi]
   ;	
   ;				MEMORY_HEAP_ITEM(prev,0) = next;
   ;	
?live16405@80: ; EDX = fs, EAX = next, ECX = size, EBX = prev
	mov       dword ptr [ebx],eax
   ;	
   ;				if (next) MEMORY_HEAP_ITEM(next,1) = prev;
   ;	
	test      eax,eax
	je        short @159
	mov       dword ptr [eax+4],ebx
	jmp       @164
   ;	
   ;				else
   ;				{
   ;					TMemItem s = (size - (MemAddSize + MemMinSize)) / MemAlign;
   ;	
?live16405@112: ; EDX = fs, ECX = size
@159:
@161:
	mov       eax,ecx
	sub       eax,16
	shr       eax,2
   ;	
   ;					if (!fs.Small[s]) fs.SmallMask &= ~(TMemItem(1) << s);
   ;	
?live16405@128: ; EDX = fs, EAX = s
	cmp       dword ptr [edx+4*eax],0
	jne       @164
	mov       ecx,eax
	mov       eax,1
	shl       eax,cl
	not       eax
	and       dword ptr [edx+132],eax
   ;	
   ;				}
   ;				return;
   ;	
?live16405@144: ; 
@163:
	jmp       @164
   ;	
   ;			}
   ;			TMemItem parent, temp, second, add;
   ;			TMemItem side = 2;
   ;	
?live16405@160: ; EAX = item, EDX = fs
@165:
@157:
	mov       dword ptr [ebp-8],2
   ;	
   ;			temp = MEMORY_HEAP_ITEM(item,3);
   ;	
	mov       ebx,dword ptr [eax+12]
   ;	
   ;			if (temp)
   ;	
?live16405@192: ; EBX = temp, EAX = item, EDX = fs
	test      ebx,ebx
	je        @167
   ;	
   ;			{
   ;				for (;;)
   ;				{
   ;					second = temp;
   ;	
@168:
	mov       esi,ebx
   ;	
   ;					temp = MEMORY_HEAP_ITEM(temp,2);
   ;	
?live16405@224: ; EBX = temp, ESI = second, EAX = item, EDX = fs
	mov       ebx,dword ptr [ebx+8]
   ;	
   ;					if (!temp) break;
   ;	
	test      ebx,ebx
	jne       short @168
   ;	
   ;				}
   ;				if (fs.Min == item) fs.Min = second;
   ;	
?live16405@256: ; EBX = temp, EAX = item, EDX = fs
	cmp       eax,dword ptr [edx+128]
	jne       short @172
	mov       dword ptr [edx+128],esi
   ;	
   ;				add = MEMORY_HEAP_ITEM(second,3);
   ;	
?live16405@272: ; ESI = second, EAX = item
@172:
	mov       edx,esi
	mov       ecx,dword ptr [edx+12]
	mov       dword ptr [ebp-4],ecx
   ;	
   ;				parent = MEMORY_HEAP_ITEM(second,0);
   ;	
?live16405@288: ; ESI = second, EAX = item, EDX = @temp13
	mov       edi,dword ptr [edx]
   ;	
   ;				if (parent == item) {parent = second; side = 3;}
   ;	
?live16405@304: ; ESI = second, EDI = parent, EAX = item, EDX = @temp13
	cmp       eax,edi
	jne       short @173
	mov       dword ptr [ebp-8],3
	mov       edi,esi
	jmp       short @174
   ;	
   ;				else
   ;				{
   ;					temp = MEMORY_HEAP_ITEM(item,3);
   ;	
@173:
	mov       ebx,dword ptr [eax+12]
   ;	
   ;					MEMORY_HEAP_ITEM(second,3) = temp;
   ;	
?live16405@336: ; EBX = temp, ESI = second, EDI = parent, EAX = item, EDX = @temp13
	;	
	mov       dword ptr [edx+12],ebx
   ;	
   ;					MEMORY_HEAP_ITEM(temp,0) = second;
   ;	
?live16405@352: ; EBX = temp, ESI = second, EDI = parent, EAX = item
	mov       dword ptr [ebx],esi
   ;	
   ;				}
   ;				temp = MEMORY_HEAP_ITEM(item,2);
   ;	
?live16405@368: ; ESI = second, EDI = parent, EAX = item
@174:
	mov       edx,eax
	mov       ebx,dword ptr [edx+8]
   ;	
   ;				MEMORY_HEAP_ITEM(second,2) = temp;
   ;	
?live16405@384: ; EBX = temp, ESI = second, EDI = parent, EAX = item, EDX = @temp17
	;	
	mov       dword ptr [esi+8],ebx
   ;	
   ;				if (temp) MEMORY_HEAP_ITEM(temp,0) = second;
   ;	
	test      ebx,ebx
	je        short @175
	mov       dword ptr [ebx],esi
   ;	
   ;				temp = MEMORY_HEAP_ITEM(item,0);
   ;	
?live16405@416: ; ESI = second, EDI = parent, EAX = item, EDX = @temp17
@175:
	mov       ebx,dword ptr [edx]
   ;	
   ;				MEMORY_HEAP_ITEM(second,0) = temp;
   ;	
?live16405@432: ; EBX = temp, ESI = second, EDI = parent, EAX = item
	mov       dword ptr [esi],ebx
   ;	
   ;				if (temp)
   ;	
	test      ebx,ebx
	je        short @177
   ;	
   ;				{
   ;					if (MEMORY_HEAP_ITEM(temp,2) == item)
   ;	
	mov       edx,ebx
	cmp       eax,dword ptr [edx+8]
	jne       short @178
   ;	
   ;					{
   ;						MEMORY_HEAP_ITEM(temp,2) = second;
   ;	
?live16405@480: ; EBX = temp, ESI = second, EDI = parent, EAX = item, EDX = @temp21
	;	
	mov       dword ptr [edx+8],esi
   ;	
   ;					}
   ;	
?live16405@496: ; ESI = second, EDI = parent, EAX = item
	jmp       short @179
   ;	
   ;					else MEMORY_HEAP_ITEM(temp,3) = second;
   ;	
?live16405@512: ; EBX = temp, ESI = second, EDI = parent, EAX = item
@178:
	mov       dword ptr [ebx+12],esi
   ;	
   ;				}
   ;				MEMORY_HEAP_ITEM(parent,side) = add;
   ;	
?live16405@528: ; ESI = second, EDI = parent, EAX = item
@179:
@177:
	mov       ecx,dword ptr [ebp-8]
	mov       edx,dword ptr [ebp-4]
	mov       dword ptr [edi+4*ecx],edx
   ;	
   ;				if (add) MEMORY_HEAP_ITEM(add,0) = parent;
   ;	
	cmp       dword ptr [ebp-4],0
	je        short @180
	mov       ecx,dword ptr [ebp-4]
	mov       dword ptr [ecx],edi
   ;	
   ;				bool color = MEMORY_HEAP_ITEM(second,1);
   ;	
@180:
@181:
	cmp       dword ptr [esi+4],0
	setne     dl
	and       edx,1
   ;	
   ;				MEMORY_HEAP_ITEM(second,1) = MEMORY_HEAP_ITEM(item,1);
   ;	
?live16405@576: ; ESI = second, EDI = parent, EAX = item, EDX = color
	mov       eax,dword ptr [eax+4]
	mov       dword ptr [esi+4],eax
   ;	
   ;				if (!color) return;
   ;	
?live16405@592: ; EDI = parent, EDX = color
	test      dl,dl
	je        @164
   ;	
   ;			}
   ;	
?live16405@608: ; EDI = parent
@183:
	jmp       short @184
   ;	
   ;			else
   ;			{
   ;				if (fs.Min == item) fs.Min = MEMORY_HEAP_ITEM(item,0);
   ;	
?live16405@624: ; EAX = item, EDX = fs
@167:
	cmp       eax,dword ptr [edx+128]
	jne       short @185
	mov       ecx,dword ptr [eax]
	mov       dword ptr [edx+128],ecx
   ;	
   ;				add = MEMORY_HEAP_ITEM(item,2);
   ;	
?live16405@640: ; EAX = item
@185:
	mov       edx,eax
	mov       ecx,dword ptr [edx+8]
	mov       dword ptr [ebp-4],ecx
   ;	
   ;				parent = MEMORY_HEAP_ITEM(item,0);
   ;				if (add) MEMORY_HEAP_ITEM(add,0) = parent;
   ;	
?live16405@656: ; EDI = parent, EAX = item
	cmp       dword ptr [ebp-4],0
?live16405@672: ; EAX = item, EDX = @temp20
	mov       edi,dword ptr [edx]
?live16405@688: ; EDI = parent, EAX = item
	je        short @186
	mov       edx,dword ptr [ebp-4]
	mov       dword ptr [edx],edi
   ;	
   ;				if (parent)
   ;	
@186:
	test      edi,edi
	je        short @187
   ;	
   ;				{
   ;					if (MEMORY_HEAP_ITEM(parent,2) == item)
   ;	
	mov       edx,edi
	cmp       eax,dword ptr [edx+8]
	jne       short @188
   ;	
   ;					{
   ;						MEMORY_HEAP_ITEM(parent,2) = add;
   ;	
?live16405@736: ; EDI = parent, EAX = item, EDX = @temp22
	mov       ecx,dword ptr [ebp-4]
	mov       dword ptr [edx+8],ecx
   ;	
   ;					}
   ;	
?live16405@752: ; EDI = parent, EAX = item
	jmp       short @189
   ;	
   ;					else
   ;					{
   ;						MEMORY_HEAP_ITEM(parent,3) = add;
   ;	
@188:
	mov       edx,dword ptr [ebp-4]
	mov       dword ptr [edi+12],edx
   ;	
   ;						side = 3;
   ;	
	mov       dword ptr [ebp-8],3
   ;	
   ;					}
   ;				}
   ;	
	jmp       short @189
   ;	
   ;				else
   ;				{
   ;					if (add) MEMORY_HEAP_ITEM(add,1) = 1; 
   ;	
?live16405@816: ; 
@187:
	cmp       dword ptr [ebp-4],0
	je        @164
	mov       eax,dword ptr [ebp-4]
	mov       dword ptr [eax+4],1
   ;	
   ;					return;
   ;	
	jmp       @164
   ;	
   ;				}
   ;				if (!MEMORY_HEAP_ITEM(item,1)) return;
   ;	
?live16405@848: ; EDI = parent, EAX = item
@189:
	cmp       dword ptr [eax+4],0
	je        @164
   ;	
   ;			}
   ;			if (add && !MEMORY_HEAP_ITEM(add,1))
   ;	
?live16405@864: ; EDI = parent
@184:
	cmp       dword ptr [ebp-4],0
	je        short @192
	mov       ecx,dword ptr [ebp-4]
	cmp       dword ptr [ecx+4],0
	jne       short @192
   ;	
   ;			{
   ;				MEMORY_HEAP_ITEM(add,1) = 1;
   ;	
?live16405@880: ; 
	mov       eax,dword ptr [ebp-4]
	mov       dword ptr [eax+4],1
   ;	
   ;				return;
   ;	
	jmp       @164
   ;	
   ;			}
   ;			for (;;)
   ;			{
   ;				second = MEMORY_HEAP_ITEM(parent,side^1);
   ;	
?live16405@912: ; EDI = parent
@192:
@193:
	mov       ebx,dword ptr [ebp-8]
	xor       ebx,1
	mov       esi,dword ptr [edi+4*ebx]
   ;	
   ;				if (!MEMORY_HEAP_ITEM(second,1))
   ;	
?live16405@928: ; ESI = second, EDI = parent, EBX = @temp6
	cmp       dword ptr [esi+4],0
	jne       short @194
   ;	
   ;				{
   ;					_RBTreeRotate(parent, second, side^1);
   ;	
	push      ebx
	push      esi
	push      edi
	call      @@MemoryHeap@_RBTreeRotate$quiuii
	add       esp,12
   ;	
   ;					second = MEMORY_HEAP_ITEM(parent,side^1);
   ;	
?live16405@960: ; EDI = parent, EBX = @temp6
	mov       esi,dword ptr [edi+4*ebx]
   ;	
   ;				}
   ;				temp = MEMORY_HEAP_ITEM(second,side^1);
   ;	
?live16405@976: ; ESI = second, EDI = parent, EBX = @temp6
@194:
	mov       ebx,dword ptr [esi+4*ebx]
   ;	
   ;				if (temp && !MEMORY_HEAP_ITEM(temp,1))
   ;	
?live16405@992: ; EBX = temp, ESI = second, EDI = parent
	test      ebx,ebx
	je        short @195
	cmp       dword ptr [ebx+4],0
	jne       short @195
   ;	
   ;				{
   ;					MEMORY_HEAP_ITEM(temp,1) = 1;
   ;	
	mov       dword ptr [ebx+4],1
   ;	
   ;					break;
   ;	
?live16405@1024: ; ESI = second, EDI = parent
	jmp       short @196
   ;	
   ;				}
   ;				temp = MEMORY_HEAP_ITEM(second,side);
   ;	
@195:
	mov       eax,dword ptr [ebp-8]
	mov       ebx,dword ptr [esi+4*eax]
   ;	
   ;				if (temp && !MEMORY_HEAP_ITEM(temp,1))
   ;	
?live16405@1056: ; EBX = temp, ESI = second, EDI = parent
	test      ebx,ebx
	je        short @197
	cmp       dword ptr [ebx+4],0
	jne       short @197
   ;	
   ;				{
   ;					_RBTreeRotate(second, temp, side);
   ;	
	mov       eax,dword ptr [ebp-8]
	push      eax
	push      ebx
	push      esi
	call      @@MemoryHeap@_RBTreeRotate$quiuii
	add       esp,12
   ;	
   ;					MEMORY_HEAP_ITEM(second,1) = 1;
   ;	
	mov       dword ptr [esi+4],1
   ;	
   ;					second = temp;
   ;	
?live16405@1104: ; EBX = temp, EDI = parent
	mov       esi,ebx
   ;	
   ;					break;
   ;	
?live16405@1120: ; ESI = second, EDI = parent
	jmp       short @196
   ;	
   ;				}
   ;				MEMORY_HEAP_ITEM(second,1) = 0;
   ;	
@197:
	xor       eax,eax
	mov       dword ptr [esi+4],eax
   ;	
   ;				if (!MEMORY_HEAP_ITEM(parent,1))
   ;	
?live16405@1152: ; EDI = parent
	mov       eax,edi
	cmp       dword ptr [eax+4],0
	jne       short @198
   ;	
   ;				{
   ;					MEMORY_HEAP_ITEM(parent,1) = 1;
   ;	
?live16405@1168: ; EDI = parent, EAX = @temp9
	mov       dword ptr [eax+4],1
   ;	
   ;					return;
   ;	
?live16405@1184: ; 
	jmp       short @164
   ;	
   ;				}
   ;				second = parent;
   ;	
?live16405@1200: ; EDI = parent
@198:
	mov       esi,edi
   ;	
   ;				parent = MEMORY_HEAP_ITEM(second,0);
   ;	
?live16405@1216: ; ESI = second
	mov       edi,dword ptr [esi]
   ;	
   ;				if (!parent) return;
   ;	
?live16405@1232: ; ESI = second, EDI = parent
	test      edi,edi
	je        short @164
   ;	
   ;				if (MEMORY_HEAP_ITEM(parent,2) == second) side = 2;
   ;	
	cmp       esi,dword ptr [edi+8]
	jne       short @200
	mov       dword ptr [ebp-8],2
	jmp       @193
   ;	
   ;				else side = 3;
   ;	
?live16405@1264: ; EDI = parent
@200:
	mov       dword ptr [ebp-8],3
	jmp       @193
   ;	
   ;			}
   ;			_RBTreeRotate(parent, second, side^1);
   ;	
?live16405@1296: ; ESI = second, EDI = parent
@196:
	mov       eax,dword ptr [ebp-8]
	xor       eax,1
	push      eax
	push      esi
	push      edi
	call      @@MemoryHeap@_RBTreeRotate$quiuii
	add       esp,12
   ;	
   ;		}
   ;	
?live16405@1312: ; 
@203:
@164:
	pop       edi
	pop       esi
	pop       ebx
	pop       ecx
	pop       ecx
	pop       ebp
	ret 
@@MemoryHeap@_FreeDel$qr21MemoryHeap@TFreeSpaceui	endp
@MemoryHeap@_FreeDel$qr21MemoryHeap@TFreeSpaceui	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@MemoryHeap@_FreeFindAfter$quiui	segment virtual
	align	2
@@MemoryHeap@_FreeFindAfter$quiui	proc	near
?live16406@0:
   ;	
   ;		TMemItem _FreeFindAfter(TMemItem item, TMemItem size)
   ;	
@204:
	push      ebp
	mov       ebp,esp
	push      ebx
	push      esi
	mov       ebx,dword ptr [ebp+12]
	mov       eax,dword ptr [ebp+8]
   ;	
   ;		{
   ;			if (!item) return 0;
   ;	
?live16406@16: ; EAX = item, EBX = size
	test      eax,eax
	jne       short @205
	xor       eax,eax
	jmp       short @206
   ;	
   ;			TMemItem paritem, s;
   ;			if (MEMORY_HEAP_NEXT(item) - item >= size) return item;
   ;	
@205:
	mov       edx,dword ptr [eax-4]
	sub       edx,eax
	cmp       ebx,edx
	jbe       short @206
   ;	
   ;			for (;;)
   ;			{
   ;				paritem = MEMORY_HEAP_ITEM(item,0);
   ;	
@208:
	mov       edx,dword ptr [eax]
   ;	
   ;				if (!paritem) break;
   ;	
?live16406@64: ; EAX = item, EDX = paritem, EBX = size
	test      edx,edx
	je        short @210
   ;	
   ;				s = MEMORY_HEAP_NEXT(paritem) - paritem;
   ;	
	mov       ecx,dword ptr [edx-4]
	sub       ecx,edx
   ;	
   ;				if (s == size) return paritem;
   ;	
?live16406@96: ; EAX = item, EDX = paritem, ECX = s, EBX = size
	cmp       ebx,ecx
	jne       short @211
	mov       eax,edx
	jmp       short @206
   ;	
   ;				if (s < size) item = paritem;
   ;	
@211:
	cmp       ebx,ecx
	jbe       short @210
	mov       eax,edx
?live16406@128: ; EAX = item, EDX = paritem, EBX = size
	jmp       short @208
   ;	
   ;				else break;
   ;			}
   ;			MEMORY_HEAP_ITEM(item,3);
   ;			for (;;)
   ;			{
   ;				if (!item) return paritem;
   ;	
@210:
@215:
	test      eax,eax
	jne       short @216
	mov       eax,edx
	jmp       short @206
   ;	
   ;				s = MEMORY_HEAP_NEXT(item) - item;
   ;	
@216:
	mov       esi,eax
	mov       ecx,dword ptr [esi-4]
	sub       ecx,eax
   ;	
   ;				if (s == size) return item;
   ;	
?live16406@176: ; EAX = item, EDX = paritem, ECX = s, EBX = size, ESI = @temp4
	cmp       ebx,ecx
	je        short @206
   ;	
   ;				if (s < size) item = MEMORY_HEAP_ITEM(item,3);
   ;	
	cmp       ebx,ecx
	jbe       short @218
	mov       eax,dword ptr [esi+12]
	jmp       short @215
   ;	
   ;				else
   ;				{
   ;					paritem = item;
   ;	
?live16406@208: ; EAX = item, EBX = size
@218:
	mov       edx,eax
   ;	
   ;					item = MEMORY_HEAP_ITEM(item,2);
   ;	
?live16406@224: ; EAX = item, EDX = paritem, EBX = size
	mov       eax,dword ptr [eax+8]
	jmp       short @215
   ;	
   ;				}
   ;			}
   ;		}
   ;	
?live16406@256: ; 
@221:
@206:
	pop       esi
	pop       ebx
	pop       ebp
	ret 
@@MemoryHeap@_FreeFindAfter$quiui	endp
@MemoryHeap@_FreeFindAfter$quiui	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@MemoryHeap@_FreeFind$qr21MemoryHeap@TFreeSpaceui	segment virtual
	align	2
@@MemoryHeap@_FreeFind$qr21MemoryHeap@TFreeSpaceui	proc	near
?live16407@0:
   ;	
   ;		TMemItem _FreeFind(TFreeSpace &fs, TMemItem size)
   ;	
@222:
	push      ebp
	mov       ebp,esp
	push      ecx
	push      ebx
	push      esi
	push      edi
	mov       esi,dword ptr [ebp+12]
	mov       edi,dword ptr [ebp+8]
   ;	
   ;		{
   ;			TMemItem item, nextitem, s;
   ;			if (size < MemAddSize + MemMinSize + MemAlign * NumTreeSmall)
   ;	
?live16407@16: ; ESI = size, EDI = fs
	cmp       esi,144
	jae       @224
   ;	
   ;			{
   ;				TMemItem m, t;
   ;				s = (size - (MemAddSize + MemMinSize)) / MemAlign;
   ;	
@225:
	mov       eax,esi
	sub       eax,16
	shr       eax,2
	mov       dword ptr [ebp-4],eax
   ;	
   ;				item = fs.Small[s];
   ;	
	mov       edx,dword ptr [ebp-4]
	mov       ebx,dword ptr [edi+4*edx]
   ;	
   ;				if (item) return item;
   ;	
?live16407@64: ; EBX = item, ESI = size, EDI = fs
	test      ebx,ebx
	je        short @226
	mov       eax,ebx
	jmp       @227
   ;	
   ;				if (size < MemAlign * NumTreeSmall)
   ;	
?live16407@80: ; ESI = size, EDI = fs
@226:
	cmp       esi,128
	jae       short @228
   ;	
   ;				{
   ;					t = size / MemAlign;
   ;	
	shr       esi,2
   ;	
   ;					m = fs.SmallMask >> t;
   ;	
?live16407@112: ; EDI = fs, ESI = t
	mov       ecx,esi
	mov       ebx,dword ptr [edi+132]
	shr       ebx,cl
   ;	
   ;					if (m) return fs.Small[t + _FirstNotZeroBit(m)];
   ;	
?live16407@128: ; EDI = fs, EBX = m, ESI = t
	test      ebx,ebx
	je        short @229
	push      ebx
	call      @@MemoryHeap@_FirstNotZeroBit$qui
	pop       ecx
	add       esi,eax
	mov       eax,dword ptr [edi+4*esi]
	jmp       @227
   ;	
   ;					else if (fs.Min) return fs.Min;
   ;	
?live16407@144: ; EDI = fs
@229:
	mov       eax,dword ptr [edi+128]
	test      eax,eax
	je        short @231
	jmp       @227
   ;	
   ;				}
   ;				else
   ;				{
   ;					item = _FreeFindAfter(fs.Min, size + 1 + MemAddSize + MemMinSize);
   ;	
?live16407@160: ; ESI = size, EDI = fs
@228:
	add       esi,17
	push      esi
	mov       eax,dword ptr [edi+128]
	push      eax
	call      @@MemoryHeap@_FreeFindAfter$quiui
	add       esp,8
	mov       ebx,eax
   ;	
   ;					if (item) return item;
   ;	
?live16407@176: ; EBX = item, EDI = fs
	test      ebx,ebx
	je        short @232
	mov       eax,ebx
	jmp       short @227
   ;	
   ;				}
   ;				m = fs.SmallMask >> s;
   ;	
?live16407@192: ; EDI = fs
@232:
@231:
	mov       ecx,dword ptr [ebp-4]
	mov       ebx,dword ptr [edi+132]
	shr       ebx,cl
   ;	
   ;				if (m) return fs.Small[s + _FirstNotZeroBit(m)];
   ;	
?live16407@208: ; EDI = fs, EBX = m
	test      ebx,ebx
	je        short @233
	push      ebx
	call      @@MemoryHeap@_FirstNotZeroBit$qui
	pop       ecx
	add       eax,dword ptr [ebp-4]
	mov       eax,dword ptr [edi+4*eax]
	jmp       short @227
   ;	
   ;				else return fs.Min;
   ;	
?live16407@224: ; EDI = fs
@233:
	mov       eax,dword ptr [edi+128]
	jmp       short @227
   ;	
   ;			}
   ;			item = _FreeFindAfter(fs.Min, ++size);
   ;	
?live16407@240: ; ESI = size, EDI = fs
@235:
@224:
	inc       esi
	push      esi
	mov       edx,dword ptr [edi+128]
	push      edx
	call      @@MemoryHeap@_FreeFindAfter$quiui
	add       esp,8
	mov       ebx,eax
   ;	
   ;			if (!item) return 0;
   ;	
?live16407@256: ; EBX = item, ESI = size
	test      ebx,ebx
	jne       short @236
	xor       eax,eax
	jmp       short @227
   ;	
   ;			s = MEMORY_HEAP_NEXT(item) - item;
   ;	
@236:
	mov       edx,dword ptr [ebx-4]
	sub       edx,ebx
	mov       dword ptr [ebp-4],edx
   ;	
   ;			if (s == size) return item;
   ;	
	cmp       esi,dword ptr [ebp-4]
	jne       short @237
	mov       eax,ebx
	jmp       short @227
   ;	
   ;			size += MemAddSize + MemMinSize;
   ;	
@237:
	add       esi,16
   ;	
   ;			if (s >= size) return item;
   ;	
	cmp       esi,dword ptr [ebp-4]
	ja        short @238
	mov       eax,ebx
	jmp       short @227
   ;	
   ;			nextitem = _FreeFindAfter(item, size);
   ;	
@238:
	push      esi
	push      ebx
	call      @@MemoryHeap@_FreeFindAfter$quiui
	add       esp,8
   ;	
   ;			return nextitem ? nextitem : item;
   ;	
?live16407@352: ; EBX = item, EAX = nextitem
	test      eax,eax
	jne       short @227
	mov       eax,ebx
   ;	
   ;		}
   ;	
?live16407@368: ; 
@241:
@227:
	pop       edi
	pop       esi
	pop       ebx
	pop       ecx
	pop       ebp
	ret 
@@MemoryHeap@_FreeFind$qr21MemoryHeap@TFreeSpaceui	endp
@MemoryHeap@_FreeFind$qr21MemoryHeap@TFreeSpaceui	ends
_TEXT	ends
_DATA	segment dword public use32 'DATA'
	align	4
$amohdaia	label	byte
	dd	0
_DATA	ends
_TEXT	segment dword public use32 'CODE'
@MemoryHeap@CreateBlock$qpvt1r21MemoryHeap@TFreeSpace	segment virtual
	align	2
@@MemoryHeap@CreateBlock$qpvt1r21MemoryHeap@TFreeSpace	proc	near
?live16408@0:
   ;	
   ;		TMemBlock CreateBlock(void *begin, void *end, TFreeSpace &fs)
   ;	
@242:
	push      ebp
	mov       ebp,esp
	push      ecx
	push      ebx
	push      esi
	push      edi
   ;	
   ;		{
   ;			TMemBlock block = {0};
   ;	
	mov       eax,dword ptr [$amohdaia]
	mov       dword ptr [ebp-4],eax
   ;	
   ;			TMemItem b = MEMORY_HEAP_ALIGN_UP(begin);
   ;	
	mov       eax,dword ptr [ebp+8]
   ;	
   ;			TMemItem e = MEMORY_HEAP_ALIGN_DOWN(end);
   ;	
?live16408@48: ; EAX = b
	mov       edx,dword ptr [ebp+12]
?live16408@64: ; 
	add       eax,3
?live16408@80: ; EAX = b
	and       edx,-4
?live16408@96: ; 
	and       eax,-4
   ;	
   ;			if (e <= b || e - b < TMemItem(BlockAddSize - MemAddSize)) return block;
   ;	
?live16408@112: ; EAX = b, EDX = e
	cmp       eax,edx
	jae       short @244
	mov       ecx,edx
	sub       ecx,eax
	cmp       ecx,16
	jae       short @243
@244:
	mov       eax,dword ptr [ebp-4]
	jmp       short @245
   ;	
   ;			block.Begin = (TMemItem*)b;
   ;	
@243:
	mov       dword ptr [ebp-4],eax
   ;	
   ;			b += MEMORY_HEAP_ALIGN_UP(4 * sizeof(TMemItem));
   ;	
	add       eax,16
   ;	
   ;			MEMORY_HEAP_PREV(b) = 0;
   ;	
	xor       ecx,ecx
   ;	
   ;			_CreateBlockEnd(block, fs, b, e);
   ;	
	mov       ebx,eax
	mov       dword ptr [eax-8],ecx
	mov       esi,edx
	mov       eax,dword ptr [ebp-4]
	mov       edx,esi
	sub       edx,ebx
	mov       edi,dword ptr [ebp+16]
	mov       dword ptr [eax],edi
	cmp       edx,16
	jae       short @246
	xor       ecx,ecx
	mov       dword ptr [ebx-4],ecx
	mov       eax,dword ptr [ebp-4]
	mov       dword ptr [eax+4],ebx
	jmp       short @247
@246:
	lea       edx,dword ptr [esi+1]
	mov       dword ptr [ebx-4],edx
	push      ebx
	push      edi
	call      @@MemoryHeap@_FreeAdd$qr21MemoryHeap@TFreeSpaceui
	add       esp,8
	xor       ecx,ecx
	mov       dword ptr [esi-8],ebx
	mov       dword ptr [esi-4],ecx
	mov       eax,dword ptr [ebp-4]
	mov       dword ptr [eax+4],esi
   ;	
   ;			return block;
   ;	
?live16408@224: ; 
@247:
	mov       eax,dword ptr [ebp-4]
   ;	
   ;		}
   ;	
@248:
@245:
	pop       edi
	pop       esi
	pop       ebx
	pop       ecx
	pop       ebp
	ret 
@@MemoryHeap@CreateBlock$qpvt1r21MemoryHeap@TFreeSpace	endp
@MemoryHeap@CreateBlock$qpvt1r21MemoryHeap@TFreeSpace	ends
_TEXT	ends
_DATA	segment dword public use32 'DATA'
	align	4
$ipohdaia	label	byte
	dd	0
_DATA	ends
_TEXT	segment dword public use32 'CODE'
@MemoryHeap@CreateBlock$qpvt1	segment virtual
	align	2
@@MemoryHeap@CreateBlock$qpvt1	proc	near
?live16409@0:
   ;	
   ;		TMemBlock CreateBlock(void *begin, void *end)
   ;	
@249:
	push      ebp
	mov       ebp,esp
	add       esp,-8
   ;	
   ;		{
   ;			TMemBlock block = {0};
   ;	
	mov       eax,dword ptr [$ipohdaia]
	push      ebx
	push      esi
	push      edi
	mov       dword ptr [ebp-4],eax
   ;	
   ;			TMemItem b = MEMORY_HEAP_ALIGN_UP(begin);
   ;	
	mov       ebx,dword ptr [ebp+8]
   ;	
   ;			TMemItem e = MEMORY_HEAP_ALIGN_DOWN(end);
   ;	
?live16409@80: ; EBX = b
	mov       esi,dword ptr [ebp+12]
?live16409@96: ; 
	add       ebx,3
?live16409@112: ; EBX = b
	and       esi,-4
?live16409@128: ; 
	and       ebx,-4
   ;	
   ;			if (e <= b || e - b < TMemItem(BlockAddSizeFS - MemAddSize)) return block;
   ;	
?live16409@144: ; EBX = b, ESI = e
	cmp       ebx,esi
	jae       short @251
	mov       eax,esi
	sub       eax,ebx
	cmp       eax,160
	jae       short @250
@251:
	mov       eax,dword ptr [ebp-4]
	jmp       short @252
   ;	
   ;			block.Begin = (TMemItem*)b;
   ;	
@250:
	mov       dword ptr [ebp-4],ebx
   ;	
   ;			b += MEMORY_HEAP_ALIGN_UP(4 * sizeof(TMemItem));
   ;	
	add       ebx,16
   ;	
   ;			TMemItem c = b + MemAddSize + MEMORY_HEAP_ALIGN_UP(sizeof(TFreeSpace));
   ;			MEMORY_HEAP_PREV(b) = 0;
   ;	
	xor       ecx,ecx
	lea       edx,dword ptr [ebx+144]
	mov       dword ptr [ebp-8],edx
	mov       dword ptr [ebx-8],ecx
   ;	
   ;			MEMORY_HEAP_NEXT(b) = c;
   ;	
	mov       eax,dword ptr [ebp-8]
	mov       dword ptr [ebx-4],eax
   ;	
   ;			MEMORY_HEAP_PREV(c) = b;
   ;	
	mov       edx,dword ptr [ebp-8]
	mov       dword ptr [edx-8],ebx
   ;	
   ;			InitFreeSpace(*(TFreeSpace*)b);
   ;	
	push      ebx
	call      @@MemoryHeap@InitFreeSpace$qr21MemoryHeap@TFreeSpace
   ;	
   ;			_CreateBlockEnd(block, *(TFreeSpace*)b, c, e);
   ;	
	mov       edi,esi
	mov       eax,dword ptr [ebp-4]
	mov       esi,dword ptr [ebp-8]
	mov       edx,edi
	sub       edx,esi
	pop       ecx
	mov       dword ptr [eax],ebx
	cmp       edx,16
	jae       short @253
	xor       ecx,ecx
	mov       dword ptr [esi-4],ecx
	mov       eax,dword ptr [ebp-4]
	mov       dword ptr [eax+4],esi
	jmp       short @254
@253:
	lea       edx,dword ptr [edi+1]
	mov       dword ptr [esi-4],edx
	push      esi
	push      ebx
	call      @@MemoryHeap@_FreeAdd$qr21MemoryHeap@TFreeSpaceui
	add       esp,8
	xor       ecx,ecx
	mov       dword ptr [edi-8],esi
	mov       dword ptr [edi-4],ecx
	mov       eax,dword ptr [ebp-4]
	mov       dword ptr [eax+4],edi
   ;	
   ;			return block;
   ;	
?live16409@336: ; 
@254:
	mov       eax,dword ptr [ebp-4]
   ;	
   ;		}
   ;	
@255:
@252:
	pop       edi
	pop       esi
	pop       ebx
	pop       ecx
	pop       ecx
	pop       ebp
	ret 
@@MemoryHeap@CreateBlock$qpvt1	endp
@MemoryHeap@CreateBlock$qpvt1	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@MemoryHeap@ResizeBlock$q20MemoryHeap@TMemBlockpv	segment virtual
	align	2
@@MemoryHeap@ResizeBlock$q20MemoryHeap@TMemBlockpv	proc	near
?live16410@0:
   ;	
   ;		void ResizeBlock(TMemBlock block, void *new_end)
   ;	
@256:
	push      ebp
	mov       ebp,esp
	push      ebx
	push      esi
	push      edi
   ;	
   ;		{
   ;			if (!BlockValid(block)) return;
   ;	
	mov       eax,dword ptr [ebp+8]
	test      eax,eax
	je        @258
   ;	
   ;			TMemItem e = MEMORY_HEAP_ALIGN_DOWN(new_end);
   ;	
?live16410@32: ; EAX = @temp4
	mov       esi,dword ptr [ebp+12]
   ;	
   ;			TMemItem c = block.Begin[1];
   ;	
?live16410@48: ; ESI = e, EAX = @temp4
	mov       ebx,dword ptr [eax+4]
?live16410@64: ; EAX = @temp4
	and       esi,-4
   ;	
   ;			TFreeSpace &fs = *(TFreeSpace*)block.Begin[0];
   ;	
?live16410@80: ; EBX = c, ESI = e, EAX = @temp4
	mov       edi,dword ptr [eax]
   ;	
   ;			do
   ;			{
   ;				if (c == e) return;
   ;	
?live16410@96: ; EBX = c, ESI = e, EDI = fs
	cmp       esi,ebx
	je        @258
   ;	
   ;				else if (c > e)
   ;	
	cmp       esi,ebx
	jae       short @261
	jmp       short @263
   ;	
   ;				{
   ;					while ((c = MEMORY_HEAP_PREV(c)) > e)
   ;					{
   ;						if (MEMORY_HEAP_FREE(c)) _FreeDel(fs, c);
   ;	
@262:
	test      byte ptr [ebx-4],1
	je        short @264
	push      ebx
	push      edi
	call      @@MemoryHeap@_FreeDel$qr21MemoryHeap@TFreeSpaceui
	add       esp,8
@264:
@263:
	mov       ebx,dword ptr [ebx-8]
	cmp       esi,ebx
	jb        short @262
   ;	
   ;					}
   ;					if (!c) {block.Begin = 0; return;}
   ;	
	test      ebx,ebx
	jne       short @266
	xor       eax,eax
	mov       dword ptr [ebp+8],eax
	jmp       @258
   ;	
   ;					if (MEMORY_HEAP_FREE(c))
   ;	
@266:
	test      byte ptr [ebx-4],1
	je        short @267
   ;	
   ;					{
   ;						_FreeDel(fs, c);
   ;	
	push      ebx
	push      edi
	call      @@MemoryHeap@_FreeDel$qr21MemoryHeap@TFreeSpaceui
	add       esp,8
   ;	
   ;						if (e - c < TMemItem(MemAddSize + MemMinSize)) e = c;
   ;	
	mov       edx,esi
	sub       edx,ebx
	cmp       edx,16
	jae       short @268
	mov       esi,ebx
	jmp       short @269
   ;	
   ;						else
   ;						{
   ;							MEMORY_HEAP_NEXT(c) = e + 1;
   ;	
?live16410@224: ; EBX = c, ESI = e
@268:
	lea       eax,dword ptr [esi+1]
	mov       dword ptr [ebx-4],eax
   ;	
   ;							_FreeAdd(*(TFreeSpace*)block.Begin[0], c);
   ;	
	push      ebx
	mov       edx,dword ptr [ebp+8]
	mov       ecx,dword ptr [edx]
	push      ecx
	call      @@MemoryHeap@_FreeAdd$qr21MemoryHeap@TFreeSpaceui
	add       esp,8
   ;	
   ;							break;
   ;	
	jmp       short @270
   ;	
   ;						}
   ;					}
   ;					else if (e - c >= TMemItem(MemAddSize + MemMinSize))
   ;	
?live16410@272: ; EBX = c, ESI = e, EDI = fs
@267:
	mov       eax,esi
	sub       eax,ebx
	cmp       eax,16
	jb        short @271
   ;	
   ;					{
   ;						MEMORY_HEAP_NEXT(c) = e; break;
   ;	
?live16410@288: ; EBX = c, ESI = e
	mov       dword ptr [ebx-4],esi
	jmp       short @270
   ;	
   ;					}
   ;					MEMORY_HEAP_NEXT(c) = 0;
   ;	
?live16410@304: ; EBX = c, ESI = e, EDI = fs
@271:
@269:
	xor       edx,edx
   ;	
   ;					block.Begin[1] = c;
   ;					if (c == e) return;
   ;	
	cmp       esi,ebx
	mov       dword ptr [ebx-4],edx
	mov       ecx,dword ptr [ebp+8]
	mov       dword ptr [ecx+4],ebx
	je        short @258
   ;	
   ;				}
   ;				TMemItem pc = MEMORY_HEAP_PREV(c);
   ;	
@261:
@274:
	mov       eax,dword ptr [ebx-8]
   ;	
   ;				if (pc && MEMORY_HEAP_FREE(pc)) _FreeDel(fs, c = pc);
   ;	
?live16410@400: ; EBX = c, ESI = e, EDI = fs, EAX = pc
	test      eax,eax
	je        short @275
	test      byte ptr [eax-4],1
	je        short @275
	mov       ebx,eax
	push      eax
	push      edi
	call      @@MemoryHeap@_FreeDel$qr21MemoryHeap@TFreeSpaceui
	add       esp,8
	jmp       short @276
   ;	
   ;				else if (e - c < TMemItem(MemAddSize + MemMinSize)) return;
   ;	
?live16410@416: ; EBX = c, ESI = e, EDI = fs
@275:
	mov       edx,esi
	sub       edx,ebx
	cmp       edx,16
	jb        short @258
   ;	
   ;				MEMORY_HEAP_NEXT(c) = e + 1;
   ;	
@276:
	lea       ecx,dword ptr [esi+1]
	mov       dword ptr [ebx-4],ecx
   ;	
   ;				_FreeAdd(fs, c);
   ;	
	push      ebx
	push      edi
	call      @@MemoryHeap@_FreeAdd$qr21MemoryHeap@TFreeSpaceui
	add       esp,8
   ;	
   ;			} while(false);
   ;			MEMORY_HEAP_PREV(e) = c;
   ;	
?live16410@464: ; EBX = c, ESI = e
@278:
@270:
	mov       eax,esi
   ;	
   ;			MEMORY_HEAP_NEXT(e) = 0;
   ;	
?live16410@480: ; ESI = e, EAX = @temp5
	xor       edx,edx
?live16410@496: ; EBX = c, ESI = e
	mov       dword ptr [eax-8],ebx
?live16410@512: ; ESI = e, EAX = @temp5
	mov       dword ptr [eax-4],edx
   ;	
   ;			block.Begin[1] = e;
   ;	
?live16410@528: ; ESI = e
	mov       ecx,dword ptr [ebp+8]
	mov       dword ptr [ecx+4],esi
   ;	
   ;		}
   ;	
?live16410@544: ; 
@279:
@258:
	pop       edi
	pop       esi
	pop       ebx
	pop       ebp
	ret 
@@MemoryHeap@ResizeBlock$q20MemoryHeap@TMemBlockpv	endp
@MemoryHeap@ResizeBlock$q20MemoryHeap@TMemBlockpv	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@MemoryHeap@RemoveBlock$q20MemoryHeap@TMemBlock	segment virtual
	align	2
@@MemoryHeap@RemoveBlock$q20MemoryHeap@TMemBlock	proc	near
?live16411@0:
   ;	
   ;		void RemoveBlock(TMemBlock block)
   ;	
@280:
	push      ebp
	mov       ebp,esp
	push      ebx
	push      esi
   ;	
   ;		{
   ;			if (!BlockValid(block)) return;
   ;	
	mov       eax,dword ptr [ebp+8]
	test      eax,eax
	je        short @282
   ;	
   ;			TMemItem e = block.Begin[1];
   ;	
?live16411@32: ; EAX = @temp2
	mov       ebx,dword ptr [eax+4]
   ;	
   ;			TFreeSpace &fs = *(TFreeSpace*)block.Begin[0];
   ;	
?live16411@48: ; EBX = e, EAX = @temp2
	mov       esi,dword ptr [eax]
	jmp       short @284
   ;	
   ;			while ((e = MEMORY_HEAP_PREV(e)) != 0)
   ;			{
   ;				if (MEMORY_HEAP_FREE(e)) _FreeDel(fs, e);
   ;	
?live16411@64: ; EBX = e, ESI = fs
@283:
	test      byte ptr [ebx-4],1
	je        short @285
	push      ebx
	push      esi
	call      @@MemoryHeap@_FreeDel$qr21MemoryHeap@TFreeSpaceui
	add       esp,8
@285:
@284:
	mov       ebx,dword ptr [ebx-8]
	test      ebx,ebx
	jne       short @283
   ;	
   ;			}
   ;			block.Begin = 0;
   ;	
?live16411@96: ; 
	xor       eax,eax
	mov       dword ptr [ebp+8],eax
   ;	
   ;		}
   ;	
@287:
@282:
	pop       esi
	pop       ebx
	pop       ebp
	ret 
@@MemoryHeap@RemoveBlock$q20MemoryHeap@TMemBlock	endp
@MemoryHeap@RemoveBlock$q20MemoryHeap@TMemBlock	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@MemoryHeap@_CopyMemItemArray$quiuiui	segment virtual
	align	2
@@MemoryHeap@_CopyMemItemArray$quiuiui	proc	near
?live16412@0:
   ;	
   ;		void _CopyMemItemArray(TMemItem dest, TMemItem src, TMemItem end)
   ;	
@288:
	push      ebp
	mov       ebp,esp
	push      ebx
	mov       eax,dword ptr [ebp+12]
   ;	
   ;		{
   ;			TMemItem k = (end - src) / sizeof(TMemItem);
   ;	
?live16412@16: ; EAX = src
	mov       ecx,dword ptr [ebp+16]
	sub       ecx,eax
   ;	
   ;			TMemItem *d = (TMemItem*)dest;
   ;	
?live16412@32: ; ECX = k, EAX = src
	mov       edx,dword ptr [ebp+8]
?live16412@48: ; EAX = src
	shr       ecx,2
   ;	
   ;			TMemItem *s = (TMemItem*)src;
   ;	
?live16412@64: ; EDX = d, ECX = k, EAX = src
	jmp       short @290
   ;	
   ;			while (k--) *(d++) = *(s++);
   ;	
?live16412@80: ; EAX = s, EDX = d, ECX = k
@289:
	mov       ebx,dword ptr [eax]
	add       eax,4
	mov       dword ptr [edx],ebx
	add       edx,4
@290:
	mov       ebx,ecx
	add       ecx,-1
	test      ebx,ebx
	jne       short @289
   ;	
   ;		}
   ;	
?live16412@96: ; 
@291:
	pop       ebx
	pop       ebp
	ret 
@@MemoryHeap@_CopyMemItemArray$quiuiui	endp
@MemoryHeap@_CopyMemItemArray$quiuiui	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@MemoryHeap@Alloc$qr21MemoryHeap@TFreeSpaceui	segment virtual
	align	2
@@MemoryHeap@Alloc$qr21MemoryHeap@TFreeSpaceui	proc	near
?live16413@0:
   ;	
   ;		void *Alloc(TFreeSpace &fs, unsigned int size)
   ;	
@292:
	push      ebp
	mov       ebp,esp
	push      ebx
	push      esi
	mov       eax,dword ptr [ebp+12]
   ;	
   ;		{
   ;			if (!size) return 0;
   ;	
?live16413@16: ; EAX = size
	test      eax,eax
	jne       short @293
	xor       eax,eax
	jmp       short @294
   ;	
   ;			TMemItem s = MEMORY_HEAP_ALIGN_UP(size) + MemAddSize;
   ;	
@293:
	lea       esi,dword ptr [eax+3]
	and       esi,-4
	add       esi,8
   ;	
   ;			if (s < MemAddSize + MemMinSize) s = MemAddSize + MemMinSize;
   ;	
?live16413@48: ; ESI = s
	cmp       esi,16
	jae       short @295
	mov       esi,16
   ;	
   ;			TMemItem c = _FreeFind(fs, s);
   ;	
@295:
	push      esi
	mov       eax,dword ptr [ebp+8]
	push      eax
	call      @@MemoryHeap@_FreeFind$qr21MemoryHeap@TFreeSpaceui
	add       esp,8
	mov       ebx,eax
   ;	
   ;			if (!c) return 0;
   ;	
?live16413@80: ; EBX = c, ESI = s
	test      ebx,ebx
	jne       short @296
	xor       eax,eax
	jmp       short @294
   ;	
   ;			_FreeDel(fs, c);
   ;	
@296:
	push      ebx
	mov       edx,dword ptr [ebp+8]
	push      edx
	call      @@MemoryHeap@_FreeDel$qr21MemoryHeap@TFreeSpaceui
	add       esp,8
   ;	
   ;			TMemItem nc = --MEMORY_HEAP_NEXT(c);
   ;	
	mov       ecx,ebx
	dec       dword ptr [ecx-4]
	mov       edx,dword ptr [ecx-4]
   ;	
   ;			TMemItem mc = c + s;
   ;	
?live16413@128: ; EBX = c, ESI = s, EDX = nc, ECX = @temp6
	lea       eax,dword ptr [esi+ebx]
   ;	
   ;			if (nc - (MemAddSize + MemMinSize) >= mc)
   ;	
?live16413@144: ; EBX = c, EAX = mc, EDX = nc, ECX = @temp6
	mov       esi,edx
	sub       esi,16
	cmp       eax,esi
	ja        short @297
   ;	
   ;			{
   ;				MEMORY_HEAP_NEXT(c) = mc;
   ;	
	mov       dword ptr [ecx-4],eax
   ;	
   ;				MEMORY_HEAP_PREV(mc) = c;
   ;	
?live16413@176: ; EBX = c, EAX = mc, EDX = nc
	mov       ecx,eax
	mov       dword ptr [ecx-8],ebx
   ;	
   ;				MEMORY_HEAP_NEXT(mc) = nc + 1;
   ;	
?live16413@192: ; EBX = c, EAX = mc, EDX = nc, ECX = @temp7
	lea       esi,dword ptr [edx+1]
	mov       dword ptr [ecx-4],esi
   ;	
   ;				MEMORY_HEAP_PREV(nc) = mc;
   ;	
?live16413@208: ; EBX = c, EAX = mc, EDX = nc
	mov       dword ptr [edx-8],eax
   ;	
   ;				_FreeAdd(fs, mc);
   ;	
?live16413@224: ; EBX = c, EAX = mc
	push      eax
	mov       eax,dword ptr [ebp+8]
	push      eax
	call      @@MemoryHeap@_FreeAdd$qr21MemoryHeap@TFreeSpaceui
	add       esp,8
   ;	
   ;			}
   ;			return (void*)c;
   ;	
?live16413@240: ; EBX = c
@297:
	mov       eax,ebx
   ;	
   ;		}
   ;	
?live16413@256: ; 
@298:
@294:
	pop       esi
	pop       ebx
	pop       ebp
	ret 
@@MemoryHeap@Alloc$qr21MemoryHeap@TFreeSpaceui	endp
@MemoryHeap@Alloc$qr21MemoryHeap@TFreeSpaceui	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@MemoryHeap@ReAlloc$qr21MemoryHeap@TFreeSpacepvui	segment virtual
	align	2
@@MemoryHeap@ReAlloc$qr21MemoryHeap@TFreeSpacepvui	proc	near
?live16414@0:
   ;	
   ;		void *ReAlloc(TFreeSpace &fs, void *mem, unsigned int size)
   ;	
@299:
	push      ebp
	mov       ebp,esp
	add       esp,-8
	push      ebx
	push      esi
	push      edi
   ;	
   ;		{
   ;			if (!mem) return Alloc(fs, size);
   ;	
?live16414@16: ; EAX = size
	cmp       dword ptr [ebp+12],0
?live16414@32: ; 
	mov       eax,dword ptr [ebp+16]
?live16414@48: ; EAX = size
	jne       short @300
	push      eax
	mov       eax,dword ptr [ebp+8]
	push      eax
	call      @@MemoryHeap@Alloc$qr21MemoryHeap@TFreeSpaceui
	add       esp,8
	jmp       @301
   ;	
   ;			if (!size) {Free(fs, mem); return 0;}
   ;	
@300:
	test      eax,eax
	jne       short @302
	mov       edx,dword ptr [ebp+12]
	push      edx
	mov       ecx,dword ptr [ebp+8]
	push      ecx
	call      @@MemoryHeap@Free$qr21MemoryHeap@TFreeSpacepv
	add       esp,8
	xor       eax,eax
	jmp       @301
   ;	
   ;			TMemItem s = MEMORY_HEAP_ALIGN_UP(size) + MemAddSize;
   ;	
@302:
	lea       edx,dword ptr [eax+3]
	and       edx,-4
	add       edx,8
	mov       dword ptr [ebp-4],edx
   ;	
   ;			TMemItem c = (TMemItem)mem;
   ;	
	mov       ebx,dword ptr [ebp+12]
   ;	
   ;			TMemItem mc = MEMORY_HEAP_NEXT(c);
   ;	
?live16414@112: ; EBX = c, EAX = size
	mov       esi,dword ptr [ebx-4]
   ;	
   ;			TMemItem nc = MEMORY_HEAP_NEXT(mc);
   ;	
?live16414@128: ; EBX = c, ESI = mc, EAX = size
	mov       edi,dword ptr [esi-4]
   ;	
   ;			if (--nc & 1) nc = mc;
   ;	
?live16414@144: ; EBX = c, ESI = mc, EDI = nc, EAX = size
	dec       edi
	test      edi,1
	je        short @303
	mov       edi,esi
   ;	
   ;			if (s < MemAddSize + MemMinSize) s = MemAddSize + MemMinSize;
   ;	
@303:
	cmp       dword ptr [ebp-4],16
	jae       short @304
	mov       dword ptr [ebp-4],16
   ;	
   ;			if (nc - c < s)
   ;	
@304:
	mov       edx,edi
	sub       edx,ebx
	cmp       edx,dword ptr [ebp-4]
	jae       @306
   ;	
   ;			{
   ;				mem = Alloc(fs, size);
   ;	
	push      eax
	mov       eax,dword ptr [ebp+8]
	push      eax
	call      @@MemoryHeap@Alloc$qr21MemoryHeap@TFreeSpaceui
	add       esp,8
	mov       dword ptr [ebp+12],eax
   ;	
   ;				if (mem)
   ;	
?live16414@208: ; EBX = c, ESI = mc, EDI = nc
	cmp       dword ptr [ebp+12],0
	je        short @307
   ;	
   ;				{
   ;					_CopyMemItemArray((TMemItem)mem, c, mc - MemAddSize);
   ;	
?live16414@224: ; EBX = c, ESI = mc
	sub       esi,8
	push      esi
	push      ebx
	mov       ecx,dword ptr [ebp+12]
	push      ecx
	call      @@MemoryHeap@_CopyMemItemArray$quiuiui
	add       esp,12
   ;	
   ;					Free(fs, (void*)c);
   ;	
?live16414@240: ; EBX = c
	push      ebx
	mov       eax,dword ptr [ebp+8]
	push      eax
	call      @@MemoryHeap@Free$qr21MemoryHeap@TFreeSpacepv
	add       esp,8
   ;	
   ;					return mem;
   ;	
?live16414@256: ; 
	mov       eax,dword ptr [ebp+12]
	jmp       @301
   ;	
   ;				}
   ;				else
   ;				{
   ;					TMemItem pc = MEMORY_HEAP_PREV(c);
   ;	
?live16414@272: ; EBX = c, ESI = mc, EDI = nc
@307:
@308:
	mov       edx,dword ptr [ebx-8]
	mov       dword ptr [ebp-8],edx
   ;	
   ;					if (pc && MEMORY_HEAP_FREE(pc) && nc - pc >= s)
   ;	
	cmp       dword ptr [ebp-8],0
	je        short @309
	mov       ecx,dword ptr [ebp-8]
	test      byte ptr [ecx-4],1
	je        short @309
	mov       eax,edi
	sub       eax,dword ptr [ebp-8]
	cmp       eax,dword ptr [ebp-4]
	jb        short @309
   ;	
   ;					{
   ;						_FreeDel(fs, pc);
   ;	
	mov       edx,dword ptr [ebp-8]
	push      edx
	mov       ecx,dword ptr [ebp+8]
	push      ecx
	call      @@MemoryHeap@_FreeDel$qr21MemoryHeap@TFreeSpaceui
	add       esp,8
   ;	
   ;						_CopyMemItemArray(pc, c, mc - MemAddSize);
   ;	
	mov       eax,esi
	sub       eax,8
	push      eax
	push      ebx
	mov       edx,dword ptr [ebp-8]
	push      edx
	call      @@MemoryHeap@_CopyMemItemArray$quiuiui
	add       esp,12
   ;	
   ;						c = pc;
   ;	
?live16414@336: ; ESI = mc, EDI = nc
	mov       ebx,dword ptr [ebp-8]
   ;	
   ;					}
   ;	
?live16414@352: ; EBX = c, ESI = mc, EDI = nc
	jmp       short @310
   ;	
   ;					else return 0;
   ;	
?live16414@368: ; 
@309:
	xor       eax,eax
	jmp       short @301
   ;	
   ;				}
   ;			}
   ;			if (mc < nc) _FreeDel(fs, mc);
   ;	
?live16414@384: ; EBX = c, ESI = mc, EDI = nc
@310:
@311:
@306:
	cmp       edi,esi
	jbe       short @313
	push      esi
	mov       edx,dword ptr [ebp+8]
	push      edx
	call      @@MemoryHeap@_FreeDel$qr21MemoryHeap@TFreeSpaceui
	add       esp,8
   ;	
   ;			mc = c + s;
   ;	
?live16414@400: ; EBX = c, EDI = nc
@313:
	mov       esi,dword ptr [ebp-4]
   ;	
   ;			if (nc - (MemAddSize + MemMinSize) >= mc)
   ;	
?live16414@416: ; EBX = c, ESI = mc, EDI = nc
	mov       eax,edi
	sub       eax,16
?live16414@432: ; EBX = c, EDI = nc
	add       esi,ebx
?live16414@448: ; EBX = c, ESI = mc, EDI = nc
	cmp       esi,eax
	ja        short @314
   ;	
   ;			{
   ;				MEMORY_HEAP_NEXT(c) = mc;
   ;	
	mov       dword ptr [ebx-4],esi
   ;	
   ;				MEMORY_HEAP_PREV(mc) = c;
   ;	
	mov       eax,esi
	mov       dword ptr [eax-8],ebx
   ;	
   ;				MEMORY_HEAP_NEXT(mc) = nc + 1;
   ;	
?live16414@496: ; EBX = c, ESI = mc, EDI = nc, EAX = @temp9
	lea       edx,dword ptr [edi+1]
	mov       dword ptr [eax-4],edx
   ;	
   ;				MEMORY_HEAP_PREV(nc) = mc;
   ;	
?live16414@512: ; EBX = c, ESI = mc, EDI = nc
	mov       dword ptr [edi-8],esi
   ;	
   ;				_FreeAdd(fs, mc);
   ;	
?live16414@528: ; EBX = c, ESI = mc
	push      esi
	mov       ecx,dword ptr [ebp+8]
	push      ecx
	call      @@MemoryHeap@_FreeAdd$qr21MemoryHeap@TFreeSpaceui
	add       esp,8
   ;	
   ;			}
   ;	
?live16414@544: ; EBX = c
	jmp       short @315
   ;	
   ;			else
   ;			{
   ;				MEMORY_HEAP_NEXT(c) = nc;
   ;	
?live16414@560: ; EBX = c, EDI = nc
@314:
	mov       dword ptr [ebx-4],edi
   ;	
   ;				MEMORY_HEAP_PREV(nc) = c;
   ;	
	mov       dword ptr [edi-8],ebx
   ;	
   ;			}
   ;			return (void*)c;
   ;	
?live16414@592: ; EBX = c
@315:
	mov       eax,ebx
   ;	
   ;		}
   ;	
?live16414@608: ; 
@316:
@301:
	pop       edi
	pop       esi
	pop       ebx
	pop       ecx
	pop       ecx
	pop       ebp
	ret 
@@MemoryHeap@ReAlloc$qr21MemoryHeap@TFreeSpacepvui	endp
@MemoryHeap@ReAlloc$qr21MemoryHeap@TFreeSpacepvui	ends
_TEXT	ends
_DATA	segment dword public use32 'DATA'
	align	4
@MemoryHeap@free_a	label	dword
	dd	0
_DATA	ends
_TEXT	segment dword public use32 'CODE'
@MemoryHeap@Free$qr21MemoryHeap@TFreeSpacepv	segment virtual
	align	2
@@MemoryHeap@Free$qr21MemoryHeap@TFreeSpacepv	proc	near
?live16415@0:
   ;	
   ;		void Free(TFreeSpace &fs, void *mem)
   ;	
@317:
	push      ebp
	mov       ebp,esp
	push      ebx
	push      esi
	push      edi
   ;	
   ;		{
   ;			TMemItem c = (TMemItem)mem;
   ;	
	mov       ebx,dword ptr [ebp+12]
   ;	
   ;			if (!c) return;
   ;	
?live16415@32: ; EBX = c
	test      ebx,ebx
	je        short @319
   ;	
   ;			TMemItem pc = MEMORY_HEAP_PREV(c);
   ;	
	mov       eax,ebx
	mov       edi,dword ptr [eax-8]
   ;	
   ;			TMemItem mc = MEMORY_HEAP_NEXT(c);
   ;	
?live16415@64: ; EBX = c, EDI = pc, EAX = @temp5
	mov       eax,dword ptr [eax-4]
   ;	
   ;			TMemItem nc = MEMORY_HEAP_NEXT(mc);
   ;	
?live16415@80: ; EBX = c, EDI = pc, EAX = mc
	mov       esi,dword ptr [eax-4]
   ;	
   ;			if (--nc & 1) nc = mc;
   ;	
?live16415@96: ; EBX = c, ESI = nc, EDI = pc, EAX = mc
	dec       esi
	test      esi,1
	je        short @320
	mov       esi,eax
	jmp       short @321
   ;	
   ;			else _FreeDel(fs, mc);
   ;	
@320:
	push      eax
	mov       eax,dword ptr [ebp+8]
	push      eax
	call      @@MemoryHeap@_FreeDel$qr21MemoryHeap@TFreeSpaceui
	add       esp,8
   ;	
   ;			if (free_a == 1) return;
   ;	
?live16415@128: ; EBX = c, ESI = nc, EDI = pc
@321:
	cmp       dword ptr [@MemoryHeap@free_a],1
	je        short @319
   ;	
   ;			if (pc && MEMORY_HEAP_FREE(pc)) _FreeDel(fs, c = pc);
   ;	
	test      edi,edi
	je        short @323
	test      byte ptr [edi-4],1
	je        short @323
	mov       ebx,edi
	push      edi
	mov       eax,dword ptr [ebp+8]
	push      eax
	call      @@MemoryHeap@_FreeDel$qr21MemoryHeap@TFreeSpaceui
	add       esp,8
   ;	
   ;			MEMORY_HEAP_NEXT(c) = nc + 1;
   ;	
?live16415@160: ; EBX = c, ESI = nc
@323:
	lea       edx,dword ptr [esi+1]
	mov       dword ptr [ebx-4],edx
   ;	
   ;			MEMORY_HEAP_PREV(nc) = c;
   ;	
	mov       dword ptr [esi-8],ebx
   ;	
   ;			if (free_a == 2) return;
   ;	
?live16415@192: ; EBX = c
	cmp       dword ptr [@MemoryHeap@free_a],2
	je        short @319
   ;	
   ;			_FreeAdd(fs, c);
   ;	
	push      ebx
	mov       ecx,dword ptr [ebp+8]
	push      ecx
	call      @@MemoryHeap@_FreeAdd$qr21MemoryHeap@TFreeSpaceui
	add       esp,8
   ;	
   ;		}
   ;	
?live16415@224: ; 
@325:
@319:
	pop       edi
	pop       esi
	pop       ebx
	pop       ebp
	ret 
@@MemoryHeap@Free$qr21MemoryHeap@TFreeSpacepv	endp
@MemoryHeap@Free$qr21MemoryHeap@TFreeSpacepv	ends
_TEXT	ends
_BSS	segment dword public use32 'BSS'
	align	4
@Menuet@_MenuetFreeSpace	label	byte
	db	136	dup(?)
	align	4
@Menuet@_MenuetMemBlock	label	byte
	db	4	dup(?)
_BSS	ends
_DATA	segment dword public use32 'DATA'
	align	4
@Menuet@_MemHeapMutex	label	byte
	dd	64
_DATA	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@_HeapInit$qpvt1t1	segment virtual
	align	2
@@Menuet@_HeapInit$qpvt1t1	proc	near
?live16416@0:
   ;	
   ;		void *_HeapInit(void *begin, void *use_end, void *end)
   ;	
@326:
	push      ebp
	mov       ebp,esp
   ;	
   ;		{
   ;			MemoryHeap::InitFreeSpace(_MenuetFreeSpace);
   ;	
	push      offset @Menuet@_MenuetFreeSpace
	call      @@MemoryHeap@InitFreeSpace$qr21MemoryHeap@TFreeSpace
	pop       ecx
   ;	
   ;			_MenuetMemBlock = MemoryHeap::CreateBlock(begin, end, _MenuetFreeSpace);
   ;	
	push      offset @Menuet@_MenuetFreeSpace
	mov       eax,dword ptr [ebp+16]
	push      eax
	mov       edx,dword ptr [ebp+8]
	push      edx
	call      @@MemoryHeap@CreateBlock$qpvt1r21MemoryHeap@TFreeSpace
	add       esp,12
	mov       dword ptr [@Menuet@_MenuetMemBlock],eax
   ;	
   ;			unsigned int use_beg = (unsigned int)MemoryHeap::BlockBegin(_MenuetMemBlock) +
   ;	
	mov       edx,dword ptr [@Menuet@_MenuetMemBlock]
	add       edx,24
	sub       edx,8
   ;	
   ;						MemoryHeap::BlockAddSize - MemoryHeap::BlockEndSize;
   ;			unsigned int use_size = (unsigned int)use_end;
   ;	
?live16416@64: ; EDX = use_beg
	mov       eax,dword ptr [ebp+12]
   ;	
   ;			if (use_size <= use_beg) return 0;
   ;	
?live16416@80: ; EAX = use_size, EDX = use_beg
	cmp       edx,eax
	jb        short @327
	xor       eax,eax
@331:
	pop       ebp
	ret 
   ;	
   ;			else use_size -= use_beg;
   ;	
@327:
	sub       eax,edx
   ;	
   ;			return MemoryHeap::Alloc(_MenuetFreeSpace, use_size);
   ;	
?live16416@112: ; EAX = use_size
	push      eax
	push      offset @Menuet@_MenuetFreeSpace
	call      @@MemoryHeap@Alloc$qr21MemoryHeap@TFreeSpaceui
	add       esp,8
   ;	
   ;		}
   ;	
?live16416@128: ; 
@330:
@328:
	pop       ebp
	ret 
@@Menuet@_HeapInit$qpvt1t1	endp
@Menuet@_HeapInit$qpvt1t1	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@Alloc$qui	segment virtual
	align	2
@@Menuet@Alloc$qui	proc	near
?live16417@0:
   ;	
   ;		void *Alloc(unsigned int size)
   ;	
@332:
	push      ebp
	mov       ebp,esp
	add       esp,-12
	push      ebx
	push      esi
	push      edi
	mov       esi,dword ptr [ebp+8]
   ;	
   ;		{
   ;			if (!size) return 0;
   ;	
?live16417@16: ; ESI = size
	test      esi,esi
	jne       short @333
	xor       eax,eax
	jmp       @334
   ;	
   ;			Lock(&_MemHeapMutex);
   ;	
@333:
	push      offset @Menuet@_MemHeapMutex
	call      @@Menuet@Lock$qp13Menuet@TMutex
	pop       ecx
   ;	
   ;			void *res = MemoryHeap::Alloc(_MenuetFreeSpace, size);
   ;	
	push      esi
	push      offset @Menuet@_MenuetFreeSpace
	call      @@MemoryHeap@Alloc$qr21MemoryHeap@TFreeSpaceui
	add       esp,8
	mov       ebx,eax
   ;	
   ;			if (!res)
   ;	
?live16417@64: ; EBX = res, ESI = size
	test      ebx,ebx
	jne       short @335
   ;	
   ;			{
   ;				unsigned use_mem = (unsigned int)MemoryHeap::BlockEndFor(_MenuetMemBlock, size);
   ;	
@336:
	mov       eax,esi
	mov       edx,dword ptr [@Menuet@_MenuetMemBlock]
	mov       dword ptr [ebp-4],edx
	mov       ecx,dword ptr [ebp-4]
	mov       edx,dword ptr [ecx+4]
	mov       dword ptr [ebp-8],edx
	mov       ecx,dword ptr [ebp-8]
	mov       edx,dword ptr [ecx-8]
	mov       dword ptr [ebp-12],edx
	mov       ecx,dword ptr [ebp-12]
	test      byte ptr [ecx-4],1
	je        short @337
	mov       edi,dword ptr [ebp-12]
	jmp       short @338
@337:
	mov       edi,dword ptr [ebp-8]
@338:
	cmp       eax,8
	ja        short @339
	mov       edx,8
	jmp       short @340
@339:
	lea       edx,dword ptr [eax+3]
	and       edx,-4
@340:
	add       edi,edx
	add       edi,8
   ;	
   ;				if (_SetUseMemory(_RecalculateUseMemory(use_mem)))
   ;	
?live16417@96: ; EBX = res, ESI = size, EDI = use_mem
	push      edi
	call      @@Menuet@_RecalculateUseMemory$qui
	pop       ecx
	push      eax
	call      @@Menuet@_SetUseMemory$qui
	pop       ecx
	test      al,al
	je        short @341
   ;	
   ;				{
   ;					res = MemoryHeap::Alloc(_MenuetFreeSpace, size);
   ;	
?live16417@112: ; ESI = size
	push      esi
	push      offset @Menuet@_MenuetFreeSpace
	call      @@MemoryHeap@Alloc$qr21MemoryHeap@TFreeSpaceui
	add       esp,8
	mov       ebx,eax
   ;	
   ;				}
   ;			}
   ;			UnLock(&_MemHeapMutex);
   ;	
?live16417@128: ; EBX = res
@341:
@342:
@335:
	push      offset @Menuet@_MemHeapMutex
	call      @@Menuet@UnLock$qp13Menuet@TMutex
	pop       ecx
   ;	
   ;			return res;
   ;	
	mov       eax,ebx
   ;	
   ;		}
   ;	
?live16417@160: ; 
@343:
@334:
	pop       edi
	pop       esi
	pop       ebx
	mov       esp,ebp
	pop       ebp
	ret 
@@Menuet@Alloc$qui	endp
@Menuet@Alloc$qui	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@ReAlloc$qpvui	segment virtual
	align	2
@@Menuet@ReAlloc$qpvui	proc	near
?live16418@0:
   ;	
   ;		void *ReAlloc(void *mem, unsigned int size)
   ;	
@344:
	push      ebp
	mov       ebp,esp
	add       esp,-12
	push      ebx
	push      esi
	push      edi
	mov       esi,dword ptr [ebp+12]
   ;	
   ;		{
   ;			Lock(&_MemHeapMutex);
   ;	
?live16418@16: ; ESI = size
	push      offset @Menuet@_MemHeapMutex
	call      @@Menuet@Lock$qp13Menuet@TMutex
	pop       ecx
   ;	
   ;			void *res = MemoryHeap::ReAlloc(_MenuetFreeSpace, mem, size);
   ;	
	push      esi
	mov       eax,dword ptr [ebp+8]
	push      eax
	push      offset @Menuet@_MenuetFreeSpace
	call      @@MemoryHeap@ReAlloc$qr21MemoryHeap@TFreeSpacepvui
	add       esp,12
	mov       ebx,eax
   ;	
   ;			if (!res && size)
   ;	
?live16418@48: ; EBX = res, ESI = size
	test      ebx,ebx
	jne       short @345
	test      esi,esi
	je        short @345
   ;	
   ;			{
   ;				unsigned use_mem = (unsigned int)MemoryHeap::BlockEndFor(_MenuetMemBlock, size);
   ;	
@346:
	mov       eax,esi
	mov       edx,dword ptr [@Menuet@_MenuetMemBlock]
	mov       dword ptr [ebp-4],edx
	mov       ecx,dword ptr [ebp-4]
	mov       edx,dword ptr [ecx+4]
	mov       dword ptr [ebp-8],edx
	mov       ecx,dword ptr [ebp-8]
	mov       edx,dword ptr [ecx-8]
	mov       dword ptr [ebp-12],edx
	mov       ecx,dword ptr [ebp-12]
	test      byte ptr [ecx-4],1
	je        short @347
	mov       edi,dword ptr [ebp-12]
	jmp       short @348
@347:
	mov       edi,dword ptr [ebp-8]
@348:
	cmp       eax,8
	ja        short @349
	mov       edx,8
	jmp       short @350
@349:
	lea       edx,dword ptr [eax+3]
	and       edx,-4
@350:
	add       edi,edx
	add       edi,8
   ;	
   ;				if (_SetUseMemory(_RecalculateUseMemory(use_mem)))
   ;	
?live16418@80: ; EBX = res, ESI = size, EDI = use_mem
	push      edi
	call      @@Menuet@_RecalculateUseMemory$qui
	pop       ecx
	push      eax
	call      @@Menuet@_SetUseMemory$qui
	pop       ecx
	test      al,al
	je        short @351
   ;	
   ;				{
   ;					res = MemoryHeap::ReAlloc(_MenuetFreeSpace, mem, size);
   ;	
?live16418@96: ; ESI = size
	push      esi
	mov       eax,dword ptr [ebp+8]
	push      eax
	push      offset @Menuet@_MenuetFreeSpace
	call      @@MemoryHeap@ReAlloc$qr21MemoryHeap@TFreeSpacepvui
	add       esp,12
	mov       ebx,eax
   ;	
   ;				}
   ;			}
   ;			UnLock(&_MemHeapMutex);
   ;	
?live16418@112: ; EBX = res
@351:
@352:
@345:
	push      offset @Menuet@_MemHeapMutex
	call      @@Menuet@UnLock$qp13Menuet@TMutex
	pop       ecx
   ;	
   ;			return res;
   ;	
	mov       eax,ebx
   ;	
   ;		}
   ;	
?live16418@144: ; 
@354:
@353:
	pop       edi
	pop       esi
	pop       ebx
	mov       esp,ebp
	pop       ebp
	ret 
@@Menuet@ReAlloc$qpvui	endp
@Menuet@ReAlloc$qpvui	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@Free$qpv	segment virtual
	align	2
@@Menuet@Free$qpv	proc	near
?live16419@0:
   ;	
   ;		void Free(void *mem)
   ;	
@355:
	push      ebp
	mov       ebp,esp
   ;	
   ;		{
   ;			Lock(&_MemHeapMutex);
   ;	
	push      offset @Menuet@_MemHeapMutex
	call      @@Menuet@Lock$qp13Menuet@TMutex
	pop       ecx
   ;	
   ;			MemoryHeap::Free(_MenuetFreeSpace, mem);
   ;	
	mov       eax,dword ptr [ebp+8]
	push      eax
	push      offset @Menuet@_MenuetFreeSpace
	call      @@MemoryHeap@Free$qr21MemoryHeap@TFreeSpacepv
	add       esp,8
   ;	
   ;			UnLock(&_MemHeapMutex);
   ;	
	push      offset @Menuet@_MemHeapMutex
	call      @@Menuet@UnLock$qp13Menuet@TMutex
	pop       ecx
   ;	
   ;		}
   ;	
@356:
	pop       ebp
	ret 
@@Menuet@Free$qpv	endp
@Menuet@Free$qpv	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@FileOpen$qpxcui	segment virtual
	align	2
@@Menuet@FileOpen$qpxcui	proc	near
?live16420@0:
   ;	
   ;		TFileData FileOpen(const char *name, unsigned int buffer_length)
   ;	
@357:
	push      ebp
	mov       ebp,esp
	add       esp,-48
	push      ebx
	push      esi
	push      edi
	mov       esi,dword ptr [ebp+12]
	mov       edi,dword ptr [ebp+8]
   ;	
   ;		{
   ;			if (!name || !name[0]) return 0;
   ;	
?live16420@16: ; ESI = buffer_length, EDI = name
	test      edi,edi
	je        short @359
	cmp       byte ptr [edi],0
	jne       short @358
@359:
	xor       eax,eax
	jmp       @360
   ;	
   ;			unsigned int name_len = StrLen(name) + 1;
   ;	
@358:
	push      edi
	call      @@Menuet@StrLen$qpxc
	inc       eax
	pop       ecx
	mov       dword ptr [ebp-4],eax
   ;	
   ;			unsigned int data_len = (_FileDataStruct::PosName + name_len + 3) & ~3;
   ;			buffer_length = (buffer_length / MENUET_FILE_BLOCK_SIZE) * MENUET_FILE_BLOCK_SIZE;
   ;	
	shr       esi,9
	mov       edx,dword ptr [ebp-4]
	add       edx,35
	shl       esi,9
	and       edx,-4
	mov       dword ptr [ebp-8],edx
   ;	
   ;			if (buffer_length) data_len += buffer_length + 2*sizeof(unsigned int);
   ;	
	test      esi,esi
	je        short @361
	lea       ecx,dword ptr [esi+8]
	add       dword ptr [ebp-8],ecx
   ;	
   ;			TFileData file = (TFileData)Alloc(_FileDataStruct::PosName + data_len);
   ;	
@361:
	mov       eax,dword ptr [ebp-8]
	add       eax,32
	push      eax
	call      @@Menuet@Alloc$qui
	pop       ecx
	mov       ebx,eax
   ;	
   ;			if (!file) return 0;
   ;	
?live16420@144: ; EBX = file, ESI = buffer_length, EDI = name
	test      ebx,ebx
	jne       short @362
	xor       eax,eax
	jmp       short @360
   ;	
   ;			file->length = -1;
   ;	
@362:
	mov       dword ptr [ebx],-1
   ;	
   ;			file->position = 0;
   ;	
	xor       edx,edx
	mov       dword ptr [ebx+4],edx
   ;	
   ;			if (buffer_length)
   ;	
	test      esi,esi
	je        short @363
   ;	
   ;			{
   ;				file->buffer = (unsigned int*)((char*)file + data_len) - 2;
   ;	
	mov       eax,dword ptr [ebp-8]
	add       eax,ebx
	add       eax,-8
   ;	
   ;				file->buffer[0] = buffer_length;
   ;				file->buffer[1] = 0;
   ;	
?live16420@224: ; EBX = file, EDI = name, EAX = @temp5
	xor       edx,edx
?live16420@240: ; EBX = file, ESI = buffer_length, EDI = name
	mov       dword ptr [ebx+8],eax
?live16420@256: ; EBX = file, ESI = buffer_length, EDI = name, EAX = @temp5
	mov       dword ptr [eax],esi
?live16420@272: ; EBX = file, EDI = name, EAX = @temp5
	mov       dword ptr [eax+4],edx
   ;	
   ;			}
   ;			MemCopy(file->access_param + 5, name, name_len);
   ;	
?live16420@288: ; EBX = file, EDI = name
@363:
	mov       ecx,dword ptr [ebp-4]
	lea       eax,dword ptr [ebx+32]
	push      ecx
	push      edi
	push      eax
	call      @@Menuet@MemCopy$qpvpxvui
   ;	
   ;			unsigned int attr[40/4];
   ;			file->access_param[0] = 5;
   ;	
?live16420@304: ; EBX = file
	mov       dword ptr [ebx+12],5
   ;	
   ;			file->access_param[1] = 0;
   ;	
	xor       edx,edx
?live16420@336: ; EBX = file, EDI = name
	add       esp,12
?live16420@352: ; EBX = file
	mov       dword ptr [ebx+16],edx
   ;	
   ;			file->access_param[2] = 0;
   ;	
	xor       ecx,ecx
	mov       dword ptr [ebx+20],ecx
   ;	
   ;			file->access_param[3] = 0;
   ;	
	xor       eax,eax
	mov       dword ptr [ebx+24],eax
   ;	
   ;			file->access_param[4] = (int)attr;
   ;	
	lea       edx,dword ptr [ebp-48]
	mov       dword ptr [ebx+28],edx
   ;	
   ;			_FileAccess(file->access_param);
   ;	
	lea       ecx,dword ptr [ebx+12]
	push      ecx
	call      @@Menuet@_FileAccess$qpv
	pop       ecx
   ;	
   ;			file->length = attr[32/4];
   ;	
	mov       eax,dword ptr [ebp-16]
	mov       dword ptr [ebx],eax
   ;	
   ;			return file;
   ;	
	mov       eax,ebx
   ;	
   ;		}
   ;	
?live16420@464: ; 
@364:
@360:
	pop       edi
	pop       esi
	pop       ebx
	mov       esp,ebp
	pop       ebp
	ret 
@@Menuet@FileOpen$qpxcui	endp
@Menuet@FileOpen$qpxcui	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@FileClose$qp22Menuet@_FileDataStruct	segment virtual
	align	2
@@Menuet@FileClose$qp22Menuet@_FileDataStruct	proc	near
?live16421@0:
   ;	
   ;		int FileClose(TFileData file_data)
   ;	
@365:
	push      ebp
	mov       ebp,esp
	mov       eax,dword ptr [ebp+8]
   ;	
   ;		{
   ;			if (!file_data) return -1;
   ;	
?live16421@16: ; EAX = file_data
	test      eax,eax
	jne       short @366
	or        eax,-1
@369:
	pop       ebp
	ret 
   ;	
   ;			Free(file_data);
   ;	
@366:
	push      eax
	call      @@Menuet@Free$qpv
	pop       ecx
   ;	
   ;			return 0;
   ;	
?live16421@48: ; 
	xor       eax,eax
   ;	
   ;		}
   ;	
@368:
@367:
	pop       ebp
	ret 
@@Menuet@FileClose$qp22Menuet@_FileDataStruct	endp
@Menuet@FileClose$qp22Menuet@_FileDataStruct	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@FileSetPosition$qp22Menuet@_FileDataStructui	segment virtual
	align	2
@@Menuet@FileSetPosition$qp22Menuet@_FileDataStructui	proc	near
?live16422@0:
   ;	
   ;		void FileSetPosition(TFileData file_data, unsigned int pos)
   ;	
@370:
	push      ebp
	mov       ebp,esp
	push      ebx
	mov       edx,dword ptr [ebp+12]
	mov       eax,dword ptr [ebp+8]
   ;	
   ;		{
   ;			if (!file_data) return;
   ;	
?live16422@16: ; EAX = file_data, EDX = pos
	test      eax,eax
	je        short @372
   ;	
   ;			if (file_data->buffer && file_data->buffer[1])
   ;	
	mov       ecx,dword ptr [eax+8]
	test      ecx,ecx
	je        short @375
	cmp       dword ptr [ecx+4],0
	je        short @375
   ;	
   ;			{
   ;				if (pos >= file_data->position && pos < file_data->position + file_data->buffer[1])
   ;	
	mov       ecx,dword ptr [eax+4]
	cmp       edx,ecx
	jb        short @376
	mov       ebx,dword ptr [eax+8]
	mov       ebx,dword ptr [ebx+4]
	add       ebx,ecx
	cmp       edx,ebx
	jae       short @376
   ;	
   ;				{
   ;					file_data->buffer[1] -= pos - file_data->position;
   ;	
?live16422@64: ; EAX = file_data, EDX = pos, ECX = @temp2
	mov       ebx,edx
	sub       ebx,ecx
	mov       ecx,dword ptr [eax+8]
	sub       dword ptr [ecx+4],ebx
   ;	
   ;				}
   ;	
?live16422@80: ; EAX = file_data, EDX = pos
	jmp       short @377
   ;	
   ;				else file_data->buffer[1] = 0;
   ;	
@376:
	mov       ecx,dword ptr [eax+8]
	xor       ebx,ebx
	mov       dword ptr [ecx+4],ebx
   ;	
   ;			}
   ;			file_data->position = pos;
   ;	
@377:
@375:
	mov       dword ptr [eax+4],edx
   ;	
   ;		}
   ;	
?live16422@128: ; 
@378:
@372:
	pop       ebx
	pop       ebp
	ret 
@@Menuet@FileSetPosition$qp22Menuet@_FileDataStructui	endp
@Menuet@FileSetPosition$qp22Menuet@_FileDataStructui	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@_FileReadBuffer$qp22Menuet@_FileDataStructpvit2	segment virtual
	align	2
@@Menuet@_FileReadBuffer$qp22Menuet@_FileDataStructpvit2	proc	near
?live16423@0:
   ;	
   ;		int _FileReadBuffer(TFileData file_data, void *mem, int size, void *temp_mem = 0)
   ;	
@379:
	push      ebp
	mov       ebp,esp
	push      ecx
	push      ebx
	push      esi
	push      edi
	mov       eax,dword ptr [ebp+20]
	mov       edi,dword ptr [ebp+16]
	mov       edx,dword ptr [ebp+12]
	mov       esi,dword ptr [ebp+8]
   ;	
   ;		{
   ;			unsigned int *buffer;
   ;			if (!file_data || !mem || size <= 0) return -1;
   ;	
?live16423@16: ; ESI = file_data, EDI = size, EDX = mem, EAX = temp_mem
	test      esi,esi
	je        short @381
	test      edx,edx
	je        short @381
	test      edi,edi
	jg        short @380
@381:
	or        eax,-1
	jmp       short @382
   ;	
   ;			if (file_data->buffer) buffer = file_data->buffer;
   ;	
@380:
	mov       ecx,dword ptr [esi+8]
	test      ecx,ecx
	je        short @383
	mov       ebx,ecx
	jmp       short @384
   ;	
   ;			else if (temp_mem)
   ;	
@383:
	test      eax,eax
	je        short @385
   ;	
   ;			{
   ;				buffer = (unsigned int*)((char*)temp_mem + MENUET_FILE_BLOCK_SIZE);
   ;	
	lea       ebx,dword ptr [eax+512]
   ;	
   ;			}
   ;	
?live16423@80: ; EBX = buffer, ESI = file_data, EDI = size, EDX = mem
	jmp       short @384
   ;	
   ;			else return 0;
   ;	
?live16423@96: ; 
@385:
	xor       eax,eax
	jmp       short @382
   ;	
   ;			if (!buffer[1]) return 0;
   ;	
?live16423@112: ; EBX = buffer, ESI = file_data, EDI = size, EDX = mem
@384:
	cmp       dword ptr [ebx+4],0
	jne       short @386
	xor       eax,eax
	jmp       short @382
   ;	
   ;			if (file_data->position >= file_data->length)
   ;	
@386:
	mov       ecx,dword ptr [esi+4]
	cmp       ecx,dword ptr [esi]
	jb        short @387
   ;	
   ;			{
   ;				buffer[1] = 0;
   ;	
?live16423@144: ; EBX = buffer
	xor       edx,edx
   ;	
   ;				return 0;
   ;	
?live16423@160: ; 
	xor       eax,eax
?live16423@176: ; EBX = buffer
	mov       dword ptr [ebx+4],edx
?live16423@192: ; 
	jmp       short @382
   ;	
   ;			}
   ;			unsigned int buf_size = file_data->length - file_data->position;
   ;	
?live16423@208: ; EBX = buffer, ESI = file_data, EDI = size, EDX = mem
@387:
	mov       ecx,dword ptr [esi]
	sub       ecx,dword ptr [esi+4]
	mov       dword ptr [ebp-4],ecx
   ;	
   ;			if (buf_size > buffer[1]) buf_size = buffer[1];
   ;	
	mov       eax,dword ptr [ebx+4]
	cmp       eax,dword ptr [ebp-4]
	jae       short @388
	mov       dword ptr [ebp-4],eax
   ;	
   ;			if ((unsigned int)size >= buf_size) size = buf_size;
   ;	
?live16423@240: ; EBX = buffer, ESI = file_data, EDI = size, EAX = @temp5, EDX = mem
	;	
@388:
	cmp       edi,dword ptr [ebp-4]
	jb        short @389
	mov       edi,dword ptr [ebp-4]
   ;	
   ;			MemCopy(mem, (char*)buffer - buffer[1], size);
   ;	
@389:
	push      edi
	mov       ecx,ebx
	sub       ecx,eax
	push      ecx
	push      edx
	call      @@Menuet@MemCopy$qpvpxvui
	add       esp,12
   ;	
   ;			file_data->position += size;
   ;	
?live16423@272: ; EBX = buffer, ESI = file_data, EDI = size
	add       dword ptr [esi+4],edi
   ;	
   ;			if ((unsigned int)size >= buf_size) buffer[1] = 0;
   ;	
?live16423@288: ; EBX = buffer, EDI = size
	cmp       edi,dword ptr [ebp-4]
	jb        short @390
	xor       eax,eax
	mov       dword ptr [ebx+4],eax
	jmp       short @391
   ;	
   ;			else buffer[1] -= size;
   ;	
@390:
	sub       dword ptr [ebx+4],edi
   ;	
   ;			return size;
   ;	
?live16423@320: ; EDI = size
@391:
	mov       eax,edi
   ;	
   ;		}
   ;	
?live16423@336: ; 
@392:
@382:
	pop       edi
	pop       esi
	pop       ebx
	pop       ecx
	pop       ebp
	ret 
@@Menuet@_FileReadBuffer$qp22Menuet@_FileDataStructpvit2	endp
@Menuet@_FileReadBuffer$qp22Menuet@_FileDataStructpvit2	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@_FileReadSystem$qp22Menuet@_FileDataStructpvi	segment virtual
	align	2
@@Menuet@_FileReadSystem$qp22Menuet@_FileDataStructpvi	proc	near
?live16424@0:
   ;	
   ;		int _FileReadSystem(TFileData file_data, void *mem, int size)
   ;	
@393:
	push      ebp
	mov       ebp,esp
	push      ebx
	push      esi
	push      edi
   ;	
   ;		{
   ;			int res;
   ;			unsigned int len0, len1;
   ;			size /= MENUET_FILE_BLOCK_SIZE;
   ;	
?live16424@16: ; EBX = file_data, ESI = size, EDI = mem
	mov       ecx,512
?live16424@32: ; 
	mov       esi,dword ptr [ebp+16]
	mov       ebx,dword ptr [ebp+8]
?live16424@48: ; EBX = file_data, ESI = size, EDI = mem
	mov       eax,esi
?live16424@64: ; 
	mov       edi,dword ptr [ebp+12]
?live16424@80: ; EBX = file_data, ESI = size, EDI = mem
	cdq
	idiv      ecx
	mov       esi,eax
   ;	
   ;			if (!file_data || !mem || size <= 0) return -1;
   ;	
	test      ebx,ebx
	je        short @395
	test      edi,edi
	je        short @395
	test      esi,esi
	jg        short @394
@395:
	or        eax,-1
	jmp       short @396
   ;	
   ;			file_data->access_param[0] = 0;
   ;	
@394:
	xor       edx,edx
   ;	
   ;			file_data->access_param[1] = (file_data->position / MENUET_FILE_BLOCK_SIZE) * MENUET_FILE_BLOCK_SIZE;
   ;			file_data->access_param[2] = 0;
   ;	
	xor       eax,eax
	mov       dword ptr [ebx+12],edx
   ;	
   ;			file_data->access_param[3] = size * MENUET_FILE_BLOCK_SIZE;
   ;	
	mov       edx,esi
	mov       ecx,dword ptr [ebx+4]
	shr       ecx,9
	shl       ecx,9
	mov       dword ptr [ebx+16],ecx
	mov       dword ptr [ebx+20],eax
	shl       edx,9
   ;	
   ;			file_data->access_param[4] = (unsigned int)mem;
   ;			res = _FileAccess(file_data->access_param);
   ;	
?live16424@224: ; EBX = file_data, ESI = size
	lea       ecx,dword ptr [ebx+12]
?live16424@240: ; EBX = file_data, ESI = size, EDI = mem
	mov       dword ptr [ebx+24],edx
	mov       dword ptr [ebx+28],edi
?live16424@272: ; EBX = file_data, ESI = size
	push      ecx
	call      @@Menuet@_FileAccess$qpv
	pop       ecx
   ;	
   ;			if (res != 0 && res != 6) return (res & 255) - 1024;
   ;	
?live16424@288: ; EBX = file_data, ESI = size, EAX = res
	test      eax,eax
	je        short @397
	cmp       eax,6
	je        short @397
	and       eax,255
	add       eax,-1024
	jmp       short @396
   ;	
   ;			if (file_data->length <= file_data->position) return 0;
   ;	
?live16424@304: ; EBX = file_data, ESI = size
@397:
	mov       edx,dword ptr [ebx+4]
	mov       eax,dword ptr [ebx]
	cmp       edx,eax
	jb        short @398
	xor       eax,eax
	jmp       short @396
   ;	
   ;			len0 = file_data->length - file_data->position;
   ;	
?live16424@320: ; EBX = file_data, ESI = size, EDX = @temp5, EAX = @temp7
@398:
	sub       eax,edx
   ;	
   ;			len1 = size * MENUET_FILE_BLOCK_SIZE - (file_data->position % MENUET_FILE_BLOCK_SIZE);
   ;	
?live16424@336: ; EBX = file_data, ESI = size, EAX = len0, EDX = @temp5
	shl       esi,9
	and       edx,511
	sub       esi,edx
	mov       edx,esi
   ;	
   ;			return (len0 <= len1) ? len0 : len1;
   ;	
?live16424@352: ; EAX = len0, EDX = len1
	cmp       edx,eax
	jae       short @396
	mov       eax,edx
   ;	
   ;		}
   ;	
?live16424@368: ; 
@401:
@396:
	pop       edi
	pop       esi
	pop       ebx
	pop       ebp
	ret 
@@Menuet@_FileReadSystem$qp22Menuet@_FileDataStructpvi	endp
@Menuet@_FileReadSystem$qp22Menuet@_FileDataStructpvi	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@_FileBufferSystem$qp22Menuet@_FileDataStructrpv	segment virtual
	align	2
@@Menuet@_FileBufferSystem$qp22Menuet@_FileDataStructrpv	proc	near
?live16425@0:
   ;	
   ;		int _FileBufferSystem(TFileData file_data, void *&temp_mem)
   ;	
@402:
	push      ebp
	mov       ebp,esp
	push      ebx
	push      esi
	push      edi
	mov       ebx,dword ptr [ebp+12]
	mov       esi,dword ptr [ebp+8]
   ;	
   ;		{
   ;			int res;
   ;			unsigned int *buffer;
   ;			if (!file_data) return -1;
   ;	
?live16425@16: ; ESI = file_data, EBX = temp_mem
	test      esi,esi
	jne       short @403
	or        eax,-1
	jmp       short @404
   ;	
   ;			if (file_data->buffer) buffer = file_data->buffer;
   ;	
@403:
	mov       eax,dword ptr [esi+8]
	test      eax,eax
	je        short @405
	mov       ebx,eax
	jmp       short @406
   ;	
   ;			else
   ;			{
   ;				if (!temp_mem)
   ;	
@405:
	cmp       dword ptr [ebx],0
	jne       short @407
   ;	
   ;				{
   ;					temp_mem = Alloc(MENUET_FILE_BLOCK_SIZE + 2*sizeof(unsigned int));
   ;	
	push      520
	call      @@Menuet@Alloc$qui
	pop       ecx
	mov       edi,eax
	mov       dword ptr [ebx],edi
   ;	
   ;					if (!temp_mem) return -10;
   ;	
?live16425@80: ; ESI = file_data, EBX = temp_mem, EDI = @temp6
	test      edi,edi
	jne       short @408
	mov       eax,-10
	jmp       short @404
   ;	
   ;				}
   ;				buffer = (unsigned int*)((char*)temp_mem + MENUET_FILE_BLOCK_SIZE);
   ;	
?live16425@96: ; ESI = file_data, EBX = temp_mem
@408:
@407:
	mov       edx,dword ptr [ebx]
	add       edx,512
	mov       ebx,edx
   ;	
   ;				buffer[0] = MENUET_FILE_BLOCK_SIZE;
   ;	
?live16425@112: ; EBX = buffer, ESI = file_data
	mov       dword ptr [ebx],512
   ;	
   ;			}
   ;			buffer[1] = buffer[0];
   ;	
@406:
	mov       eax,dword ptr [ebx]
   ;	
   ;			res = _FileReadSystem(file_data, (char*)buffer - buffer[1], buffer[1]);
   ;	
?live16425@144: ; EBX = buffer, ESI = file_data, EAX = @temp4
	mov       edx,ebx
?live16425@160: ; EBX = buffer, ESI = file_data
	mov       dword ptr [ebx+4],eax
?live16425@176: ; EBX = buffer, ESI = file_data, EAX = @temp4
	push      eax
	sub       edx,eax
	push      edx
	push      esi
	call      @@Menuet@_FileReadSystem$qp22Menuet@_FileDataStructpvi
	add       esp,12
   ;	
   ;			if (res < 0) buffer[1] = 0;
   ;	
?live16425@192: ; EBX = buffer, ESI = file_data, EAX = res
	test      eax,eax
	jge       short @409
	xor       ecx,ecx
	mov       dword ptr [ebx+4],ecx
	jmp       short @404
   ;	
   ;			else buffer[1] -= file_data->position % MENUET_FILE_BLOCK_SIZE;
   ;	
@409:
	mov       edx,dword ptr [esi+4]
	and       edx,511
	sub       dword ptr [ebx+4],edx
   ;	
   ;			return res;
   ;		}
   ;	
?live16425@224: ; 
@411:
@404:
	pop       edi
	pop       esi
	pop       ebx
	pop       ebp
	ret 
@@Menuet@_FileBufferSystem$qp22Menuet@_FileDataStructrpv	endp
@Menuet@_FileBufferSystem$qp22Menuet@_FileDataStructrpv	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@FileTestRead$qp22Menuet@_FileDataStruct	segment virtual
	align	2
@@Menuet@FileTestRead$qp22Menuet@_FileDataStruct	proc	near
?live16426@0:
   ;	
   ;		int FileTestRead(TFileData file_data)
   ;	
@412:
	push      ebp
	mov       ebp,esp
	push      ecx
	push      ebx
	mov       eax,dword ptr [ebp+8]
   ;	
   ;		{
   ;			int res;
   ;			void *temp_mem = 0;
   ;	
?live16426@16: ; EAX = file_data
	xor       edx,edx
	mov       dword ptr [ebp-4],edx
   ;	
   ;			if (!file_data) return -1;
   ;	
	test      eax,eax
	jne       short @413
	or        eax,-1
	jmp       short @414
   ;	
   ;			if (file_data->buffer && file_data->buffer[1]) return 0;
   ;	
@413:
	mov       edx,dword ptr [eax+8]
	test      edx,edx
	je        short @415
	cmp       dword ptr [edx+4],0
	je        short @415
	xor       eax,eax
	jmp       short @414
   ;	
   ;			res = _FileBufferSystem(file_data, temp_mem);
   ;	
@415:
	lea       ecx,dword ptr [ebp-4]
	push      ecx
	push      eax
	call      @@Menuet@_FileBufferSystem$qp22Menuet@_FileDataStructrpv
	add       esp,8
	mov       ebx,eax
   ;	
   ;			if (temp_mem) Free(temp_mem);
   ;	
?live16426@80: ; EBX = res
	cmp       dword ptr [ebp-4],0
	je        short @416
	mov       eax,dword ptr [ebp-4]
	push      eax
	call      @@Menuet@Free$qpv
	pop       ecx
   ;	
   ;			return (res < 0) ? res : 0;
   ;	
@416:
	test      ebx,ebx
	jge       short @417
	mov       eax,ebx
	jmp       short @414
@417:
	xor       eax,eax
   ;	
   ;		}
   ;	
?live16426@112: ; 
@419:
@414:
	pop       ebx
	pop       ecx
	pop       ebp
	ret 
@@Menuet@FileTestRead$qp22Menuet@_FileDataStruct	endp
@Menuet@FileTestRead$qp22Menuet@_FileDataStruct	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@Menuet@FileRead$qp22Menuet@_FileDataStructpvi	segment virtual
	align	2
@@Menuet@FileRead$qp22Menuet@_FileDataStructpvi	proc	near
?live16427@0:
   ;	
   ;		int FileRead(TFileData file_data, void *mem, int size)
   ;	
@420:
	push      ebp
	mov       ebp,esp
	add       esp,-8
   ;	
   ;		{
   ;			int tlen, res, read_len;
   ;			void *temp_mem = 0;
   ;	
?live16427@16: ; ESI = file_data, EDI = size
	xor       eax,eax
?live16427@32: ; 
	push      ebx
	push      esi
	push      edi
	mov       edi,dword ptr [ebp+16]
	mov       esi,dword ptr [ebp+8]
?live16427@48: ; ESI = file_data, EDI = size
	mov       dword ptr [ebp-8],eax
   ;	
   ;			res = _FileReadBuffer(file_data, mem, size);
   ;	
	push      0
	push      edi
	mov       edx,dword ptr [ebp+12]
	push      edx
	push      esi
	call      @@Menuet@_FileReadBuffer$qp22Menuet@_FileDataStructpvit2
	add       esp,16
	mov       ebx,eax
   ;	
   ;			if (res < 0 || res >= size) return res;
   ;	
?live16427@80: ; EBX = res, ESI = file_data, EDI = size
	test      ebx,ebx
	jl        short @422
	cmp       edi,ebx
	jg        short @421
@422:
	mov       eax,ebx
	jmp       @423
   ;	
   ;			read_len = res;
   ;	
@421:
	mov       dword ptr [ebp-4],ebx
   ;	
   ;			mem = (char*)mem + res;
   ;	
	add       dword ptr [ebp+12],ebx
   ;	
   ;			size -= res;
   ;	
	sub       edi,ebx
   ;	
   ;			tlen = file_data->position % MENUET_FILE_BLOCK_SIZE;
   ;	
?live16427@144: ; ESI = file_data, EDI = size
	mov       eax,dword ptr [esi+4]
	and       eax,511
   ;	
   ;			if (tlen)
   ;	
?live16427@160: ; ESI = file_data, EDI = size, EAX = tlen
	test      eax,eax
	je        short @424
   ;	
   ;			{
   ;				res = _FileBufferSystem(file_data, temp_mem);
   ;	
?live16427@176: ; ESI = file_data, EDI = size
	lea       edx,dword ptr [ebp-8]
	push      edx
	push      esi
	call      @@Menuet@_FileBufferSystem$qp22Menuet@_FileDataStructrpv
	add       esp,8
	mov       ebx,eax
   ;	
   ;				if (res < 0)
   ;	
?live16427@192: ; EBX = res, ESI = file_data, EDI = size
	test      ebx,ebx
	jge       short @425
   ;	
   ;				{
   ;					if (temp_mem) Free(temp_mem);
   ;	
?live16427@208: ; EBX = res
	cmp       dword ptr [ebp-8],0
	je        short @426
	mov       eax,dword ptr [ebp-8]
	push      eax
	call      @@Menuet@Free$qpv
	pop       ecx
   ;	
   ;					return read_len ? read_len : res;
   ;	
@426:
	cmp       dword ptr [ebp-4],0
	je        short @427
	mov       eax,dword ptr [ebp-4]
	jmp       @423
@427:
	mov       eax,ebx
	jmp       @423
   ;	
   ;				}
   ;				res = _FileReadBuffer(file_data, mem, size);
   ;	
?live16427@240: ; ESI = file_data, EDI = size
@425:
	push      0
	push      edi
	mov       edx,dword ptr [ebp+12]
	push      edx
	push      esi
	call      @@Menuet@_FileReadBuffer$qp22Menuet@_FileDataStructpvit2
	add       esp,16
	mov       ebx,eax
   ;	
   ;				read_len += res;
   ;	
?live16427@256: ; EBX = res, ESI = file_data, EDI = size
	add       dword ptr [ebp-4],ebx
   ;	
   ;				if (res >= size || file_data->length <= file_data->position ||
   ;	
	cmp       edi,ebx
	jle       short @430
	mov       eax,dword ptr [esi]
	cmp       eax,dword ptr [esi+4]
	jbe       short @430
	mov       edx,dword ptr [esi]
	sub       edx,dword ptr [esi+4]
	cmp       edx,ebx
	ja        short @429
   ;	
   ;					file_data->length - file_data->position <= res)
   ;				{
   ;					if (temp_mem) Free(temp_mem);
   ;	
?live16427@288: ; 
@430:
	cmp       dword ptr [ebp-8],0
	je        short @431
	mov       ecx,dword ptr [ebp-8]
	push      ecx
	call      @@Menuet@Free$qpv
	pop       ecx
   ;	
   ;					return read_len;
   ;	
@431:
	mov       eax,dword ptr [ebp-4]
	jmp       @423
   ;	
   ;				}
   ;				mem = (char*)mem + res;
   ;	
?live16427@320: ; EBX = res, ESI = file_data, EDI = size
@429:
	add       dword ptr [ebp+12],ebx
   ;	
   ;				size -= res;
   ;	
	sub       edi,ebx
   ;	
   ;			}
   ;			if (size >= (file_data->buffer ? file_data->buffer[0] : MENUET_FILE_BLOCK_SIZE))
   ;	
?live16427@352: ; ESI = file_data, EDI = size
@424:
	cmp       dword ptr [esi+8],0
	je        short @433
	mov       edx,dword ptr [esi+8]
	mov       ecx,dword ptr [edx]
	jmp       short @434
@433:
	mov       ecx,512
@434:
	cmp       ecx,edi
	ja        short @432
   ;	
   ;			{
   ;				res = _FileReadSystem(file_data, mem, size);
   ;	
	push      edi
	mov       eax,dword ptr [ebp+12]
	push      eax
	push      esi
	call      @@Menuet@_FileReadSystem$qp22Menuet@_FileDataStructpvi
	add       esp,12
	mov       ebx,eax
   ;	
   ;				if (res < 0)
   ;	
?live16427@384: ; EBX = res, ESI = file_data, EDI = size
	test      ebx,ebx
	jge       short @435
   ;	
   ;				{
   ;					if (temp_mem) Free(temp_mem);
   ;	
?live16427@400: ; EBX = res
	cmp       dword ptr [ebp-8],0
	je        short @436
	mov       eax,dword ptr [ebp-8]
	push      eax
	call      @@Menuet@Free$qpv
	pop       ecx
   ;	
   ;					return read_len ? read_len : res;
   ;	
@436:
	cmp       dword ptr [ebp-4],0
	je        short @437
	mov       eax,dword ptr [ebp-4]
	jmp       @423
@437:
	mov       eax,ebx
	jmp       @423
   ;	
   ;				}
   ;				file_data->position += res;
   ;	
?live16427@432: ; EBX = res, ESI = file_data, EDI = size
@435:
	add       dword ptr [esi+4],ebx
   ;	
   ;				read_len += res;
   ;	
	add       dword ptr [ebp-4],ebx
   ;	
   ;				if (res < (size / MENUET_FILE_BLOCK_SIZE) * MENUET_FILE_BLOCK_SIZE)
   ;	
	mov       edx,edi
	test      edx,edx
	jns       short @440
	add       edx,511
@440:
	sar       edx,9
	shl       edx,9
	cmp       ebx,edx
	jge       short @439
   ;	
   ;				{
   ;					if (temp_mem) Free(temp_mem);
   ;	
?live16427@480: ; 
	cmp       dword ptr [ebp-8],0
	je        short @441
	mov       ecx,dword ptr [ebp-8]
	push      ecx
	call      @@Menuet@Free$qpv
	pop       ecx
   ;	
   ;					return read_len;
   ;	
@441:
	mov       eax,dword ptr [ebp-4]
	jmp       short @423
   ;	
   ;				}
   ;				mem = (char*)mem + res;
   ;	
?live16427@512: ; EBX = res, ESI = file_data, EDI = size
@439:
	add       dword ptr [ebp+12],ebx
   ;	
   ;				size -= res;
   ;	
	sub       edi,ebx
   ;	
   ;			}
   ;			if (size)
   ;	
?live16427@544: ; ESI = file_data, EDI = size
@432:
	test      edi,edi
	je        short @442
   ;	
   ;			{
   ;				res = _FileBufferSystem(file_data, temp_mem);
   ;	
	lea       edx,dword ptr [ebp-8]
	push      edx
	push      esi
	call      @@Menuet@_FileBufferSystem$qp22Menuet@_FileDataStructrpv
	add       esp,8
	mov       ebx,eax
   ;	
   ;				if (res < 0)
   ;	
?live16427@576: ; EBX = res, ESI = file_data, EDI = size
	test      ebx,ebx
	jge       short @443
   ;	
   ;				{
   ;					if (temp_mem) Free(temp_mem);
   ;	
?live16427@592: ; EBX = res
	cmp       dword ptr [ebp-8],0
	je        short @444
	mov       eax,dword ptr [ebp-8]
	push      eax
	call      @@Menuet@Free$qpv
	pop       ecx
   ;	
   ;					return read_len ? read_len : res;
   ;	
@444:
	cmp       dword ptr [ebp-4],0
	je        short @445
	mov       eax,dword ptr [ebp-4]
	jmp       short @423
@445:
	mov       eax,ebx
	jmp       short @423
   ;	
   ;				}
   ;				read_len += _FileReadBuffer(file_data, mem, size, temp_mem);
   ;	
?live16427@624: ; ESI = file_data, EDI = size
@443:
	mov       edx,dword ptr [ebp-8]
	push      edx
	push      edi
	mov       ecx,dword ptr [ebp+12]
	push      ecx
	push      esi
	call      @@Menuet@_FileReadBuffer$qp22Menuet@_FileDataStructpvit2
	add       esp,16
	add       dword ptr [ebp-4],eax
   ;	
   ;			}
   ;			if (temp_mem) Free(temp_mem);
   ;	
?live16427@640: ; 
@442:
	cmp       dword ptr [ebp-8],0
	je        short @447
	mov       eax,dword ptr [ebp-8]
	push      eax
	call      @@Menuet@Free$qpv
	pop       ecx
   ;	
   ;			return read_len;
   ;	
@447:
	mov       eax,dword ptr [ebp-4]
   ;	
   ;		}
   ;	
@448:
@423:
	pop       edi
	pop       esi
	pop       ebx
	pop       ecx
	pop       ecx
	pop       ebp
	ret 
@@Menuet@FileRead$qp22Menuet@_FileDataStructpvi	endp
@Menuet@FileRead$qp22Menuet@_FileDataStructpvi	ends
_TEXT	ends
_DATA	segment dword public use32 'DATA'
_header	label	byte
	db	72
	db	101
	db	108
	db	108
	db	111
	db	87
	db	111
	db	114
	db	108
	db	100
	db	32
	db	116
	db	101
	db	115
	db	116
	db	0
_string	label	byte
	db	72
	db	101
	db	108
	db	108
	db	111
	db	44
	db	32
	db	87
	db	111
	db	114
	db	108
	db	100
	db	33
	db	0
_DATA	ends
_TEXT	segment dword public use32 'CODE'
@MenuetOnStart$qr17Menuet@TStartDatappv	segment virtual
	align	2
@@MenuetOnStart$qr17Menuet@TStartDatappv	proc	near
?live16428@0:
   ;	
   ;	bool MenuetOnStart(TStartData &me_start, TThreadData /*th*/)
   ;	
@449:
	push      ebp
	mov       ebp,esp
	mov       eax,dword ptr [ebp+8]
   ;	
   ;	{
   ;		me_start.Left = 10;
   ;	
?live16428@16: ; EAX = me_start
	mov       word ptr [eax],10
   ;	
   ;		me_start.Top = 40;
   ;	
	mov       word ptr [eax+4],40
   ;	
   ;		me_start.Width = 150;
   ;	
	mov       word ptr [eax+2],150
   ;	
   ;		me_start.Height = 30;
   ;	
	mov       word ptr [eax+6],30
   ;	
   ;		me_start.WinData.Title = header;
   ;	
	mov       dword ptr [eax+28],offset _header
   ;	
   ;		return true;
   ;	
?live16428@96: ; 
	mov       al,1
   ;	
   ;	}
   ;	
@451:
@450:
	pop       ebp
	ret 
@@MenuetOnStart$qr17Menuet@TStartDatappv	endp
@MenuetOnStart$qr17Menuet@TStartDatappv	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@MenuetOnDraw$qv	segment virtual
	align	2
@@MenuetOnDraw$qv	proc	near
?live16429@0:
   ;	
   ;	void MenuetOnDraw(void)
   ;	{
   ;		DrawString(30,10,0,string);
   ;	
@452:
	push      offset _string
	push      0
	push      10
	push      30
	call      @@Menuet@DrawString$qssipxc
	add       esp,16
   ;	
   ;	}
   ;	
@453:
	ret 
@@MenuetOnDraw$qv	endp
@MenuetOnDraw$qv	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@MenuetOnClose$qppv	segment virtual
	align	2
@@MenuetOnClose$qppv	proc	near
?live16430@0:
   ;	
   ;	bool MenuetOnClose(TThreadData /*th*/)
   ;	
@454:
	push      ebp
	mov       ebp,esp
   ;	
   ;	{return true;}
   ;	
	mov       al,1
@456:
@455:
	pop       ebp
	ret 
@@MenuetOnClose$qppv	endp
@MenuetOnClose$qppv	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@MenuetOnIdle$qppv	segment virtual
	align	2
@@MenuetOnIdle$qppv	proc	near
?live16431@0:
   ;	
   ;	int MenuetOnIdle(TThreadData /*th*/)
   ;	
@457:
	push      ebp
	mov       ebp,esp
   ;	
   ;	{return -1;}
   ;	
	or        eax,-1
@459:
@458:
	pop       ebp
	ret 
@@MenuetOnIdle$qppv	endp
@MenuetOnIdle$qppv	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@MenuetOnSize$qpippv	segment virtual
	align	2
@@MenuetOnSize$qpippv	proc	near
?live16432@0:
   ;	
   ;	void MenuetOnSize(int /*window_rect*/[], TThreadData /*th*/)
   ;	
@460:
	push      ebp
	mov       ebp,esp
   ;	
   ;	{}
   ;	
@461:
	pop       ebp
	ret 
@@MenuetOnSize$qpippv	endp
@MenuetOnSize$qpippv	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@MenuetOnKeyPress$qppv	segment virtual
	align	2
@@MenuetOnKeyPress$qppv	proc	near
?live16433@0:
   ;	
   ;	void MenuetOnKeyPress(TThreadData /*th*/)
   ;	
@462:
	push      ebp
	mov       ebp,esp
   ;	
   ;	{GetKey();}
   ;	
	call      @@Menuet@GetKey$qv
@463:
	pop       ebp
	ret 
@@MenuetOnKeyPress$qppv	endp
@MenuetOnKeyPress$qppv	ends
_TEXT	ends
_TEXT	segment dword public use32 'CODE'
@MenuetOnMouse$qppv	segment virtual
	align	2
@@MenuetOnMouse$qppv	proc	near
?live16434@0:
   ;	
   ;	void MenuetOnMouse(TThreadData /*th*/)
   ;	
@464:
	push      ebp
	mov       ebp,esp
   ;	
   ;	{}
   ;	
@465:
	pop       ebp
	ret 
@@MenuetOnMouse$qppv	endp
@MenuetOnMouse$qppv	ends
_TEXT	ends
_DATA	segment dword public use32 'DATA'
s@	label	byte
	;	s@+0:
	db	"User program: ",0
	align	4
_DATA	ends
_TEXT	segment dword public use32 'CODE'
_TEXT	ends
	public	@Menuet@DebugPrefix
	public	@Menuet@_ThreadTable
	public	@Menuet@_ThreadScanCount
	public	@Menuet@_ThreadNumber
	public	@Menuet@_ExitProcessNow
	public	@Menuet@_ThreadMutex
	public	@Menuet@_ThreadSavedBegProc
@@Menuet@ReadCommonColors$qpui equ @Menuet@ReadCommonColors$qpui
 extrn   @Menuet@ReadCommonColors$qpui:near
@@Menuet@GetPid$qv equ @Menuet@GetPid$qv
 extrn   @Menuet@GetPid$qv:near
@@Menuet@Lock$qp13Menuet@TMutex equ @Menuet@Lock$qp13Menuet@TMutex
 extrn   @Menuet@Lock$qp13Menuet@TMutex:near
@@Menuet@ExitProcess$qv equ @Menuet@ExitProcess$qv
 extrn   @Menuet@ExitProcess$qv:near
@@Menuet@_HashByte$qui equ @Menuet@_HashByte$qui
 extrn   @Menuet@_HashByte$qui:near
@@Menuet@UnLock$qp13Menuet@TMutex equ @Menuet@UnLock$qp13Menuet@TMutex
 extrn   @Menuet@UnLock$qp13Menuet@TMutex:near
@@Menuet@GetPid$qppv equ @Menuet@GetPid$qppv
 extrn   @Menuet@GetPid$qppv:near
@@Menuet@_GetSkinHeader$qv equ @Menuet@_GetSkinHeader$qv
 extrn   @Menuet@_GetSkinHeader$qv:near
@@Menuet@GetMousePosition$qrst1o equ @Menuet@GetMousePosition$qrst1o
 extrn   @Menuet@GetMousePosition$qrst1o:near
@@Menuet@GetThreadData$qv equ @Menuet@GetThreadData$qv
 extrn   @Menuet@GetThreadData$qv:near
	public	@MemoryHeap@free_a
	public	@Menuet@_MenuetFreeSpace
	public	@Menuet@_MenuetMemBlock
	public	@Menuet@_MemHeapMutex
@@Menuet@_SetUseMemory$qui equ @Menuet@_SetUseMemory$qui
 extrn   @Menuet@_SetUseMemory$qui:near
@@Menuet@_RecalculateUseMemory$qui equ @Menuet@_RecalculateUseMemory$qui
 extrn   @Menuet@_RecalculateUseMemory$qui:near
@@Menuet@StrLen$qpxc equ @Menuet@StrLen$qpxc
 extrn   @Menuet@StrLen$qpxc:near
@@Menuet@MemCopy$qpvpxvui equ @Menuet@MemCopy$qpvpxvui
 extrn   @Menuet@MemCopy$qpvpxvui:near
@@Menuet@_FileAccess$qpv equ @Menuet@_FileAccess$qpv
 extrn   @Menuet@_FileAccess$qpv:near
@@Menuet@DrawString$qssipxc equ @Menuet@DrawString$qssipxc
 extrn   @Menuet@DrawString$qssipxc:near
@@Menuet@GetKey$qv equ @Menuet@GetKey$qv
 extrn   @Menuet@GetKey$qv:near
	?debug	D "include\me_file.h" 13656 25646
	?debug	D "include\memheap.h" 12936 41126
	?debug	D "include\me_heap.h" 12936 41432
	?debug	D "include\me_func.inc" 13910 801
	?debug	D "include\me_lib.h" 12931 45849
	?debug	D "include\menuet.h" 13910 1090
	?debug	D "hello.cpp" 13910 1166
	end
